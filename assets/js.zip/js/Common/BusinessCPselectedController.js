
var url=base_url.baseurl;





viewDemowebsitesForPackages();   
        function viewDemowebsitesForPackages(){
            $.ajax({
                type  : 'GET',
                url   : url+"Common/SearchWebsitesForBusinessList",
                async : true,
                dataType : 'json',
                success : function(result){
     if(result.success==true){
        viewDemowebsitesForPackagesList(result.data);
      
              }        
                }
            });
        }

  function viewDemowebsitesForPackagesList(demowebsites){
       var items = "";
       var edititems = "";
       var i;
       var n = demowebsites.length;

    for(var i=0; i<n; i++){
        items+='<div class="col-md-4 col-6 form-group"><div class="demoweb card"><img src="'+url+demowebsites[i].web_photo+'" alt="web image" class="image"><div class="container"><h6 class="p-2">'+demowebsites[i].web_name+'</h6></div><div class="overlay"><div class="text"><a  href="'+demowebsites[i].web_url+'" class="btn btn-info btn-rounded btn-fw mb-3" target="_blank">Live Demo</a><a  href="'+demowebsites[i].web_url+'" class="btn btn-light btn-rounded btn-fw" target="_blank">Preview</a></div></div></div></div>';
     }    

        // $("#demowebsitesbusiness").html(items);
        $("#demowebsitespackages").html(items);;
  
  }
function searchdemowebsitesByCategoryForPackages(search_website){

  var search_business_website = search_website;

 var items =" ";
   $.ajax({
       type:"POST",
       url:url+"Common/SearchWebsitesForBusinessList",
    dataType: 'json',
    data:{search_business_website:search_business_website},
    dataType: 'json',

 success: function(result){
      
      if(result.success==true){
        
        viewDemowebsitesForPackagesList(result.data);  
      }
  else if(result.success==false){
        $('#search_packages_website-msg').hide().fadeIn('').delay(1000).fadeOut(2200);
        $( "#search_packages_website-msg" ).html("<div class='alert alert-danger'>"+result.message+"</div>");
      }
    },
    
    failure: function (result){
      $('#search_packages_website-msg').hide().fadeIn('slow').delay(1000).fadeOut(2200);
      $( "#search_packages_website-msg" ).html("<div class='alert alert-danger'>Some thing went wrong try again ...</div>");      
    } 
         
      });

}


var packagesform = $("#add_packagesdata");
packagesform.validate({
    errorPlacement: function errorPlacement(error, element) { element.before(error); },
    rules: {
      // add_packages_companyname :"required",
      // add_business_campaign :"required",
      add_package_condition:"required",
      add_packages_debitcardno:{number:true,minlength:5, maxlength:18},
      add_packages_creditcardno:{number:true,minlength:5, maxlength:18},
      add_packages_chequeno:{number:true,minlength:4, maxlength:12},
      add_packages_cchequeno:{number:true,minlength:4, maxlength:12,equalTo:"#add_packages_chequeno"},
      add_packages_cheque_micr:{number:true},
      add_packages_accountno:{number:true,minlength:5, maxlength:20},
      add_packages_caccountno: {number:true,minlength:5, maxlength:20,equalTo: "#add_business_accountno"},
      add_packages_cacholdername: { equalTo: "#add_business_acholdername"},
      add_business_phonepay:{number:true,minlength:10, maxlength:12},
      add_business_amazonpay:{number:true,minlength:10, maxlength:12},
      add_business_googlepay:{number:true,minlength:10, maxlength:12},
    
    }
});



packagesform.children("div").steps({
    headerTag: "h3",
    bodyTag: "section",
    transitionEffect: "slideLeft",
    onStepChanging: function (event, currentIndex, newIndex)
    {   
      var search_website = $("#add_packages_businesskeyword:checked").val();

         searchdemowebsitesByCategoryForPackages(search_website);

      var paymentmodeid = $("#add_business_payment_mode:checked").val();
         
         var add_business_creditcard_expireddate=$("#add_newbusiness_payment_mode").val();
         var add_business_creditcardno=$("#add_business_creditcardno").val();
         
         if(paymentmodeid==3 && (!add_business_creditcard_expireddate || add_business_creditcard_expireddate.length<=0) && (!add_business_creditcardno ||  add_business_creditcardno.length<=0)){
            alert("Please fill all Credit Card Mode options!!!");
            return false;
         }
         
         var add_business_chequeaccountno=$("#add_packages_chequeaccountno").val();
         var add_business_chequeno=$("#add_packages_chequeno").val();
         var add_business_cchequeno=$("#add_packages_cchequeno").val();
         var add_business_cheque_micr=$("#add_packages_cheque_micr").val();
         var add_business_cheque_photo=$("#add_packages_cheque_photo").val();
         var add_business_chequeissuedate=$("#add_packages_chequeissuedate").val();
         
         if(paymentmodeid==6 && (!add_business_chequeaccountno || add_business_chequeaccountno.length<=0) && (!add_business_chequeno ||  add_business_chequeno.length<=0) && (!add_business_cchequeno || add_business_cchequeno.length<=0) && (!add_business_cheque_micr || add_business_cheque_micr.length<=0) && (!add_business_cheque_photo || add_business_cheque_photo.length<=0) && (!add_business_chequeissuedate || add_business_chequeissuedate.length<=0)){
            alert("Please fill all Cheque Mode options!!!");
            return false;
         }
         
         var add_business_cashamount=$("#add_packages_cashamount").val();
         var add_business_cashdate=$("#add_packages_cashdate").val();
         var add_business_personame=$("#add_packages_personame").val();
         var add_business_placename=$("#add_packages_placename").val();
         
         
         if(paymentmodeid==1 && (!add_business_cashamount || add_business_cashamount.length<=0) && (!add_business_cashdate ||  add_business_cashdate.length<=0) && (!add_business_personame ||  add_business_personame.length<=0) && (!add_business_placename ||  add_business_placename.length<=0)){
            alert("Please fill all Cash Mode options!!!");
            return false;
         }
         
         if (currentIndex < newIndex)
        {
            // To remove error styles
            $(".body:eq(" + newIndex + ") label.error", packagesform).remove();
            $(".body:eq(" + newIndex + ") .error", packagesform).removeClass("error");
        }
        //alert(businessform.valid());
        var result = $('ul[aria-label=Pagination]').children().find('a');
        $(result).each(function ()  { 
           if($(this).text() == 'Finish') {
               $(this).attr('disabled', true);
               $(this).css('background', 'green');
               
           }
           });
        
        //alert(currentIndex);
        
        packagesform.validate().settings.ignore = ":disabled,:hidden";
        return packagesform.valid();
     
    },
    onStepChanged: function (event, currentIndex)
    {    
         var total=0;
         var packagetotal=0;
         var campaigntotal=0;
     $('#totalamount1').show();  
     // $('#grandtotalamount').hide(); 
      $('#campaignlist1').empty();
        var n = $("#add_business_campaign:checked").length;
        if (n > 0){
            $("#add_business_campaign:checked").each(function(){
                //var campaign_id= $(this).val();
                var campainname=$(this).attr("data-cname");
                var campaignamount=$(this).attr("data-camount");
                campaigntotal += Number(campaignamount);

        $('#campaignlist1').append('<div class="col-sm-6 col-6 form-group" id="pakagesname"><label>'+campainname+'</label></div> <div class="col-sm-6 col-6 form-group" id="pakagesname"><label>'+campaignamount+'</label></div>');   
  
            });

        }

        $('#packagelist1').empty();
        var n = $("#add_business_package:checked").length;
        if (n > 0){
            $("#add_business_package:checked").each(function(){
                //var campaign_id= $(this).val();
                var packagename=$(this).attr("data-pname");
                var packageamount=$(this).attr("data-pamount");
               packagetotal += Number(packageamount); 
        $('#packagelist1').append('<div class="col-sm-6 col-6 form-group" id="pakagesname"><label>'+packagename+'</label></div> <div class="col-sm-6 col-6 form-group" id="pakagesname"><label>'+packageamount+'</label></div>');   
  
            });
        }
       
      var total=campaigntotal+packagetotal;
      var total= parseFloat(total).toFixed(2);
     var state_id = $('#add_packages_companyname_state_id').val();
     if(state_id==32){
        var cgst=Number(total*9/100);
        var sgst=Number(total*9/100);

        var cgst= parseFloat(cgst).toFixed(2);
        var sgst= parseFloat(sgst).toFixed(2);
        var grandtoatal= parseFloat(total) + parseFloat(cgst)+parseFloat(sgst);
        var grandtoatal= parseFloat(grandtoatal).toFixed(2);

        var gst='<div class="col-sm-6 col-12 form-group"> <label> CGST </label></div> <div class="col-sm-6 col-12 form-group"><label>'+cgst+'</label></div> <div class="col-sm-6 col-12 form-group"> <label> SGST</label></div> <div class="col-sm-6 col-12 form-group"><label>'+sgst+'</label></div>';

       
     }else if(state_id!=32){
       var igst=Number(total*18/100);
       var igst= parseFloat(igst).toFixed(2);
       var grandtoatal= parseFloat(total) + parseFloat(igst);
       var grandtoatal= parseFloat(grandtoatal).toFixed(2);
      gst='<div class="col-sm-6 col-12 form-group"> <label>IGST</label></div> <div class="col-sm-6 col-12 form-group"><label>'+igst+'</label></div> ';
     } 
     // alert(grandtoatal);
     $('#totalamount1').empty();
     $('#totalamount1').append('<div class="col-sm-12 col-12"> <div class="row clearfixed"> <div class="col-sm-6 col-12 form-group"> <label> Gross Amount </label></div> <div class="col-sm-6 col-12 form-group"><label>'+total+'</label></div>'+gst+'<div class="col-sm-6 col-12 form-group"> <label> Total Amount </label></div> <div class="col-sm-6 col-12 form-group"><label>'+grandtoatal+'</label></div>           </div></div>')
      
      $('#add_packages_total').val(total);
      

    },
    onFinishing: function (event, currentIndex)
    {  
        packagesform.validate().settings.ignore = ":disabled";
        return packagesform.valid();
       
    },
    onFinished: function (event, currentIndex)
    {

    var business_id=$('#add_packages_companyname').val();   
    var formData = new FormData($("#add_packagesdata")[0] );
     $.ajax({
    type:"POST",
    url:url+"BusinessCPselectedController/savePackagesData",
    dataType: 'json',
    data:formData,
    contentType: false, 
    cache: false,      
    processData:false,
 beforeSend: function(){
    // Show image container
    $(".loader").show();
},
   

      success: function(result){
      
      if(result.success==true){

        $('#packagesdata-addmsg').hide().fadeIn('slow').delay(1000).fadeOut(2200);   
        $( "#packagesdata-addmsg" ).html("<div class='alert alert-success'>"+result.message+"</div>");
        $('#add_packagesdata')[0].reset();
        
         window.setTimeout(function(){location.reload()},3000)

         }
      else{
        $('#packagesdata-addmsg').hide().fadeIn('').delay(1000).fadeOut(2200);
        $( "#packagesdata-addmsg" ).html("<div class='alert alert-danger'>"+result.message+"</div>");
      }
    },
   complete:function(){
    // Hide image container
    $(".loader").hide();
},    
    failure: function (result){

      $('#packagesdata-addmsg').hide().fadeIn('slow').delay(1000).fadeOut(2200);
      $( "#packagesdata-addmsg" ).html("<div class='alert alert-danger'>Some thing went wrong try again ...</div>");     
    } 
         
      });

    }
});



$(document).ready(function(){

 $("#applypromocode").click(function(){
 
 var add_packages_promocode = $('#add_packages_promocode').val();
 var totalamount = $('#add_packages_total').val();
 var add_packages_companyname = $('#add_packages_companyname').val();
 var state_id = $('#add_packages_companyname_state_id').val();
 //var totalamount = $(this).attr("data-total");
 //alert(totalamount);
//alert(add_packages_promocode);
    $.ajax({
    type: "POST",
    url:url+'BusinessCPselectedController/getAmountPromocode',
    data:{add_packages_promocode:add_packages_promocode,add_packages_companyname:add_packages_companyname},
    dataType: 'json',
  beforeSend: function(){
    // Show image container
    $(".loader").show();
},  
  success:function(result){
      if(result.success===true)
      { 

 var discountamount=0 ;
 
if(result.data[0].discount_amount !='NULL' && result.data[0].discount_amount >0){
$( "#promcodeamount-msg" ).html("<div class='alert alert-success'>"+result.data[0].discount_amount+"Rs Discount to Using this Promocode </div>"); 

  discountamount=result.data[0].discount_amount;
  var discountamount= parseFloat(discountamount).toFixed(2);

}else if(result.data[0].discount_percentage != 'NULL' && result.data[0].discount_percentage != ' '){
$("#promcodeamount-msg" ).html("<div class='alert alert-success'>"+result.data[0].discount_percentage+"% Discount to Using this Promocode </div>");   
        var percentage=result.data[0].discount_percentage; 
        discountamount =(totalamount/100) * percentage ; 
        var discountamount= parseFloat(discountamount).toFixed(2);
       

}

$('#totalamount1').hide();  
    $('#grandtotalamount').empty();
   var total=totalamount-discountamount;
   var total= parseFloat(total).toFixed(2);
    if(state_id==32){
        var cgst=Number(total*9/100);
        var sgst=Number(total*9/100);

        var cgst= parseFloat(cgst).toFixed(2);
        var sgst= parseFloat(sgst).toFixed(2);
        var grandtoatal= parseFloat(total) + parseFloat(cgst)+parseFloat(sgst);
        var grandtoatal= parseFloat(grandtoatal).toFixed(2);

        var gst='<div class="col-sm-6 col-12"> <label> CGST </label></div> <div class="col-sm-6 col-12"><label>'+cgst+'</label></div> <div class="col-sm-6 col-12"> <label> SGST</label></div> <div class="col-sm-6 col-12"><label>'+sgst+'</label></div>';
       
     }else{
       var igst=Number(total*18/100);
       var igst= parseFloat(igst).toFixed(2);
       var grandtoatal= parseFloat(total) + parseFloat(igst);
       var grandtoatal= parseFloat(grandtoatal).toFixed(2);
       var gst='<div class="col-sm-6 col-12"> <label>IGST</label></div> <div class="col-sm-6 col-12"><label>'+igst+'</label></div> ';
      
     } 

      $('#grandtotalamount').append('<div class="col-sm-12 col-12"> <div class="row clearfixed">                                            <div class="col-sm-6 col-12"><label> Actual Price </label></div> <div class="col-sm-6 col-12"><label>'+totalamount+'</label></div>      <div class="col-sm-6 col-12"><label> Discount Amount </label></div> <div class="col-sm-6 col-12"><label>'+discountamount+'</label></div> <div class="col-sm-6 col-12"><label> Discount Price </label></div> <div class="col-sm-6 col-12"><label>'+total+'</label></div> '+gst+'<div class="col-sm-6 col-12 "> <label> Total Amount </label></div> <div class="col-sm-6 col-12"><label>'+grandtoatal+'</label></div>  </div></div>')

 // $('#discount').empty();
 //      $('#discount').append('<div class="col-sm-12 col-12"> <div class="row clearfixed"><div class="col-sm-6 col-12"><label> Discount Amount </label></div> <div class="col-sm-6 col-12"><label>'+discountamount+'</label></div></div></div>')
  $('#add_packages_discountamount').val(discountamount);
  $('#add_packages_grandtotal').val(total);
   $('#add_packages_total').val('');

  $('#add_packages_promocode_id').val(result.data[0].id);

      }else if(result.success==false){
        
        $('#totalamount1').hide();  

            $('#grandtotalamount').empty();
            $('#discount').empty();
             $('#promcodeamount-msg').hide().fadeIn('slow').delay(1000).fadeOut(2200);   
             $("#promcodeamount-msg" ).html("<div class='alert alert-danger'>"+result.message+"</div>"); 

                  var total=totalamount;
  if(state_id==32){
        var cgst=Number(total*9/100);
        var sgst=Number(total*9/100);
        var cgst= parseFloat(cgst).toFixed(2);
        var sgst= parseFloat(sgst).toFixed(2);
        var grandtoatal= parseFloat(total) + parseFloat(cgst)+parseFloat(sgst);
        var grandtoatal= parseFloat(grandtoatal).toFixed(2);

          var gst='<div class="col-sm-6 col-12"> <label> CGST </label></div> <div class="col-sm-6 col-12"><label>'+cgst+'</label></div> <div class="col-sm-6 col-12 "> <label> SGST</label></div> <div class="col-sm-6 col-12"><label>'+sgst+'</label></div>';
       
     }else if(state_id!=32){
       var igst=Number(total*18/100);
       var igst= parseFloat(igst).toFixed(2);
       var grandtoatal= parseFloat(total) + parseFloat(igst);
       var grandtoatal= parseFloat(grandtoatal).toFixed(2);
      var gst='<div class="col-sm-6 col-12"> <label>IGST</label></div> <div class="col-sm-6 col-12"><label>'+igst+'</label></div> '
     } 

     $('#grandtotalamount').append('<div class="col-sm-12 col-12"> <div class="row clearfixed"><div class="col-sm-6 col-12"><label> Actual Price </label></div> <div class="col-sm-6 col-12"><label>'+totalamount+'</label></div>'+gst+'<div class="col-sm-6 col-12 "> <label> Total Amount </label></div> <div class="col-sm-6 col-12"><label>'+grandtoatal+'</label></div> </div></div>')
     $('#add_packages_grandtotal').val('');
     $('#add_packages_total').val(total);
     
      }

    },
   complete:function(){
    // Hide image container
    $(".loader").hide();
},
 failure:function(result){
      
      alert('Information request failed: ' + textStatus, 'error');
    }


});

    

    });




viewBusinessKeywords();   
        function viewBusinessKeywords(){
            $.ajax({
                type  : 'GET',
                url   : url+"Common/getBusinessKeywordslist",
                async : true,
                dataType : 'json',
                success : function(result){
     if(result.success==true){
        businesskeywordsview(result.data);
      
              }        
                }
            });
        }

  function businesskeywordsview(keywordlist){
    
       var items = "";
       var edititems = "";
       var i;
       var n = keywordlist.length;

for(i=0;i<n;i++) {
   items+= '<div class="col-md-4 col-12 form-group"> <input type="radio"  value='+keywordlist[i].id+' id="add_business_businesskeyword" name="add_business_businesskeyword"  style="display: inline;"> <span class="form-label" for="add_business_businesskeyword"> '+keywordlist[i].category_name+' </span></div>'

   edititems+= '<div class="col-md-4 col-12 form-group"> <input type="radio"  value='+keywordlist[i].id+' id="add_packages_businesskeyword" name="add_packages_businesskeyword"  style="display: inline;"> <span class="form-label" for="add_packages_businesskeyword"> '+keywordlist[i].category_name+' </span></div>'

       }

         $("#addkeywordsbusiness").html(items);
         $("#addkeywordspackages").html(edititems);
  
  }

$("#add_keywords").validate({
     
     rules:{
        add_keywords_name :"required",
        add_keywords_category:"required"
     }
 });


$("#addkeywords").click(function() {
  
    if(!$("#add_keywords").valid())
   {
     return false;
   }
  
   var formData = new FormData($("#add_keywords")[0] );
     $.ajax({
      type:"POST",
    url:url+"Common/saveKeywords",
    dataType: 'json',
    data:formData,
    contentType: false, 
    cache: false,      
    processData:false,
  
  success: function(result){
      if(result.success==true){
        $('#keywords-addmsg').hide().fadeIn('slow').delay(1000).fadeOut(2200);    
          $( "#keywords-addmsg" ).html("<div class='alert alert-success'>"+result.message+"</div>");
        $('#add_keywords')[0].reset();
        setTimeout(function(){
               $('#AddkeywordsModal').modal("hide");
                    }, 5000); 
         viewBusinessKeywords(); 
      }
      else{
        $('#keywords-addmsg').hide().fadeIn('').delay(1000).fadeOut(2200);
        $( "#keywords-addmsg" ).html("<div class='alert alert-danger'>"+result.message+"</div>");
      }
    },
    
    failure: function (result){

      $('#keywords-addmsg').hide().fadeIn('slow').delay(1000).fadeOut(2200);
      $( "#keywords-addmsg" ).html("<div class='alert alert-danger'>Some thing went wrong try again ...</div>");      
    } 
        });

});


// $("#searchpackageskeywordscategory").click(function(){
  $( "#search_packages_keyword" ).keyup(function() {
var search_business_keyword = $('#search_packages_keyword').val();
 var items =" ";
   $.ajax({
       type:"POST",
       url:url+"Common/SearchKeywordsForBusinessList",
    dataType: 'json',
    data:{search_business_keyword:search_business_keyword},
    dataType: 'json',

 success: function(result){
      
      if(result.success===true){

          businesskeywordsview(result.data)
   }
  else if(result.success===false){
        $('#search_packages_keywords-msg').hide().fadeIn('').delay(1000).fadeOut(2200);
        $( "#search_packages_keywords-msg" ).html("<div class='alert alert-danger'>"+result.message+"</div>");
      }
    },
    
    failure: function (result){
      $('#search_packages_keywords-msg').hide().fadeIn('slow').delay(1000).fadeOut(2200);
      $( "#search_packages_keywords-msg" ).html("<div class='alert alert-danger'>Some thing went wrong try again ...</div>");      
    } 
         
      });

});

$("#searchpackageswebcategory").click(function(){
  var search_website = $('#search_packages_website').val();
  searchdemowebsitesByCategoryForPackages(search_website);
});

$("#packages_generated_opt").click(function() {

var add_packages_companyname = $("#add_packages_companyname").val();
var add_business_payment_mode =$("input:radio[name=add_business_payment_mode]:checked").val();    
// var add_business_payment_mode = $("#add_business_payment_mode").val();
var add_packages_total = $("#add_packages_total").val();
var add_packages_grandtotal = $("#add_packages_grandtotal").val();
   $.ajax({
    type:"POST",
    url:url+"Welcome/OtpSendToMobileForpackage",
    dataType: 'json',
    data:{add_packages_companyname:add_packages_companyname,add_business_payment_mode:add_business_payment_mode,add_packages_total:add_packages_total,add_packages_grandtotal:add_packages_grandtotal},
    dataType: 'json',

 success: function(result){
      
      if(result.success==true){
          alert(result.message);
           $('#package_otpverficationmodal').modal('show');
        }
  else if(result.success==false){
        alert(result.message);
      }
    },
    
    failure: function (result){
      alert("Some thing went wrong try again ...");
    } 
         
      });

});

// }


$("#package_otp_verification").click(function() {
var package_mobileOtp = $("#package_mobileOtp").val();
   $.ajax({
       type:"POST",
       url:url+"Welcome/OtpVerficationToMobileForpackage",
    dataType: 'json',
    data:{package_mobileOtp:package_mobileOtp},
    dataType: 'json',
 success: function(result){
      
      if(result.success==true){
        $('#add_package_otp').val(package_mobileOtp);
        $('#package_otpverficationmodal').modal('hide');    
        alert(result.message);
   }
  else if(result.success===false){
       alert(result.message);
      }
    },
    
    failure: function (result){
     alert("Some thing went wrong try again ...");
    } 
         
      });

});

//====  Invoice Start=== //

   $('#invoice_pdf').click(excelexport);
   $('#invoice_print').click(excelexport);
      function DownloadExcelInvoice(link) {
        var downloadurl=url+link;
        window.open(downloadurl, '_blank');
      }
      function excelexport(){
        var business_invoice_selectedid = $("#business_invoice_selectedid").val();
        var export_type='';
        var id = this.id;
        if(id=='invoice_pdf'){
          export_type=$("#invoice_pdf").val();  
        }
        if(id=='invoice_print'){
          export_type=$("#invoice_print").val(); 
        }
        // var obj=  {business_invoice_selectedid: business_invoice_selectedid,export_type:export_type};
        // var data = JSON.stringify(obj);
        
        jQuery.ajax({
          type: "POST",
          url:url+"BusinessCPselectedController/invoiceExport",
          dataType: 'json',
          data:{business_invoice_selectedid: business_invoice_selectedid,export_type:export_type},
          success: function(result){
            if(result.success===true){
                 $('#msg').hide().fadeIn('slow').delay(1350).fadeOut(2200);   
                 $("#msg").html("<div class='alert alert-success'>"+result.message+"</div>");
                if(result.download_type=='pdf'){
                  DownloadExcelInvoice(result.data);
                  return false;
                }else{
                  
                    var printWindow = window.open('', '');
                    printWindow.document.write('<html><head><title>Invoice</title>');
                    printWindow.document.write('<link rel="stylesheet" href="'+url+'assets/vendors/css/vendor.bundle.base.css">');
                    printWindow.document.write('<link rel="stylesheet"  href="'+url+'assets/css/vertical-layout-light/style.css">');
                    printWindow.document.write('<link rel="stylesheet" href="'+url+'assets/css/custom.css">');
                    printWindow.document.write('</head><body >');
                    printWindow.document.write(result.data);
                    printWindow.document.write('</body></html>');
                    printWindow.document.close();
                    printWindow.print();
                    
                }
                
            }
            else{
              //window.location.href= '';
              setTimeout(function(){
                $('#msg').html('<div class="alert alert-failure">No Data !...</div>');
              },1000);
              }
          },
          failure: function (result){
            setTimeout(function(){
              $('#msg').html('<div class="alert alert-failure">Something went wrong in App!...</div>');
            },1000);
            
          }
        });
      }

      $("#invoice_sendmail").click(function(){
      var business_invoice_selectedid = $('#business_invoice_selectedid').val();
       var items =" ";
         $.ajax({
             type:"POST",
             url:url+"BusinessCPselectedController/invoiceSendToMail",
          dataType: 'json',
          data:{business_invoice_selectedid:business_invoice_selectedid},
          dataType: 'json',
      beforeSend: function(){
          // Show image container
          $(".loader").show();
      },
       success: function(result){
            
            if(result.success===true){
              $('#invoice_sendmail_msg').hide().fadeIn('').delay(1000).fadeOut(2200);
              $( "#invoice_sendmail_msg" ).html("<div class='alert alert-danger'>"+result.message+"</div>");
         }
        else if(result.success===false){
              $('#invoice_sendmail_msg').hide().fadeIn('').delay(1000).fadeOut(2200);
              $( "#invoice_sendmail_msg" ).html("<div class='alert alert-danger'>"+result.message+"</div>");
            }
          },
       
        complete:function(){
          // Hide image container
          $(".loader").hide();
      },

          failure: function (result){
            $('#receipt_sendmail_msg').hide().fadeIn('slow').delay(1000).fadeOut(2200);
            $( "#receipt_sendmail_msg").html("<div class='alert alert-danger'>Some thing went wrong try again ...</div>");      
          } 
               
            });

      });

//====  Invoice end=== //


//==== send Email Receipt Start=== //

    $('#receipt_pdf').click(receiptexport);
    $('#receipt_print').click(receiptexport);

    function DownloadExcelReceipt(link) {
      var downloadurl=url+link;
      window.open(downloadurl, '_blank');
    }

    function receiptexport(){
      var business_receipt_selectedid = $("#business_receipt_selectedid").val();
      var export_type='';
      var id = this.id;
      if(id=='receipt_pdf'){
        export_type=$("#receipt_pdf").val();  
      }
      if(id=='receipt_print'){
        export_type=$("#receipt_print").val(); 
      }
      // var obj=  {business_receipt_selectedid: business_receipt_selectedid,export_type:export_type};
      // var data = JSON.stringify(obj);
      jQuery.ajax({
        type: "POST",
        url:url+"BusinessCPselectedController/receiptExport",
        dataType: 'JSON',
        data:{business_receipt_selectedid: business_receipt_selectedid,export_type:export_type},
        success: function(result){
          if(result.success===true){
               $('#msg').hide().fadeIn('slow').delay(1350).fadeOut(2200);   
              $("#msg").html("<div class='alert alert-success'>"+result.message+"</div>");
              if(result.download_type=='pdf'){
                DownloadExcelReceipt(result.data);
                return false;
              }else{
                
                  var printWindow = window.open('', '');
                  printWindow.document.write('<html><head><title>Receipt</title>');
                  printWindow.document.write('<link rel="stylesheet" href="'+url+'assets/vendors/css/vendor.bundle.base.css">');
                  printWindow.document.write('<link rel="stylesheet"  href="'+url+'assets/css/vertical-layout-light/style.css">');
                  printWindow.document.write('<link rel="stylesheet" href="'+url+'assets/css/custom.css">');
                  printWindow.document.write('</head><body >');
                  printWindow.document.write(result.data);
                  printWindow.document.write('</body></html>');
                  printWindow.document.close();
                  printWindow.print();
                  
              }
              
          }
          else{
            //window.location.href= '';
            setTimeout(function(){
              $('#msg').html('<div class="alert alert-failure">No Data !...</div>');
            },1000);
            }
        },
        failure: function (result){
          setTimeout(function(){
            $('#msg').html('<div class="alert alert-failure">Something went wrong in App!...</div>');
          },1000);
          
        }
      });
    }

    $("#receipt_sendmail").click(function(){
    var business_receipt_selectedid = $('#business_receipt_selectedid').val();
     var items =" ";
       $.ajax({
           type:"POST",
           url:url+"BusinessCPselectedController/receiptSendToMail",
        dataType: 'json',
        data:{business_receipt_selectedid:business_receipt_selectedid},
        dataType: 'json',
    beforeSend: function(){
        // Show image container
        $(".loader").show();
    },
     success: function(result){
          if(result.success===true){
            $('#receipt_sendmail_msg').hide().fadeIn('').delay(1000).fadeOut(2200);
            $( "#receipt_sendmail_msg" ).html("<div class='alert alert-danger'>"+result.message+"</div>");
       }
      else if(result.success===false){
            $('#receipt_sendmail_msg').hide().fadeIn('').delay(1000).fadeOut(2200);
            $( "#receipt_sendmail_msg" ).html("<div class='alert alert-danger'>"+result.message+"</div>");
          }
        },
      complete:function(){
        // Hide image container
        $(".loader").hide();
        },
        failure: function (result){
          $('#receipt_sendmail_msg').hide().fadeIn('slow').delay(1000).fadeOut(2200);
          $( "#receipt_sendmail_msg").html("<div class='alert alert-danger'>Some thing went wrong try again ...</div>");      
        } 
             
          });
       });
//====Receipt end=== //

  }); // document ready