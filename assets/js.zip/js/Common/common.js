
var url=base_url.baseurl;

function convert_number(number)
{
   if ((number < 0) || (number > 999999999))
    {
      return "Number is out of range";
    }
    var Gn = Math.floor(number / 10000000);  /* Crore */
    number -= Gn * 10000000;
    var kn = Math.floor(number / 100000);     /* lakhs */
    number -= kn * 100000;
    var Hn = Math.floor(number / 1000);      /* thousand */
    number -= Hn * 1000;
    var Dn = Math.floor(number / 100);       /* Tens (deca) */
    number = number % 100;               /* Ones */
    var tn= Math.floor(number / 10);
    var one=Math.floor(number % 10);
    var res = "";

    if (Gn>0)
    {
        res += (convert_number(Gn) + " Crore");
    }
    if (kn>0)
    {
            res += (((res=="") ? "" : " ") +
            convert_number(kn) + " Lakhs");
    }
    if (Hn>0)
    {
        res += (((res=="") ? "" : " ") +
            convert_number(Hn) + " Thousand");
    }

    if (Dn)
    {
        res += (((res=="") ? "" : " ") +
            convert_number(Dn) + " hundred");
    }


    var ones = Array("", "One", "Two", "Three", "Four", "Five", "Six","Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve", "Thirteen","Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eightteen","Nineteen");
var tens = Array("", "", "Twenty", "Thirty", "Fourty", "Fifty", "Sixty","Seventy", "Eigthy", "Ninety");
   
    if (tn>0 || one>0)
    {
        if (!(res==""))
        {
            res += " and ";
        }
        if (tn < 2)
        {
            res += ones[tn * 10 + one];
        }
        else
        {

            res += tens[tn];
            if (one>0)
            {
                res += ("-" + ones[one]);
            }
        }
    }
   
    if (res=="")
    {
        res = "zero";
    }
    return res;
}
$(function(){          
  var items="";
      $.getJSON(url+"Common/getMarketLeadUsers",function(email){
      items+="<option value=''>--Select Market Lead Users--</option>";
      $.each(email,function(index,itemlist){ 
      $.each(itemlist,function(index,item) {
      items+="<option value='"+item.id+"'>"+item.email+"</option>";
        });
      });
      $("#add_marketlead_user").html(items);
      $("#edit_marketlead_user").html(items);
      // $("#edit_user").html(items);
    });
       // $("#add_user").select2();
});

$(function(){          
  var items="";
      $.getJSON(url+"Common/getMarketingUsers",function(email){
      items+="<option value=''>--Select Marketing Users--</option>";
      $.each(email,function(index,itemlist){
      $.each(itemlist,function(index,item) {
      items+="<option value='"+item.id+"'>"+item.email+"</option>";
        });
      });
      $("#add_user").html(items);
      $("#edit_user").html(items);
    });
       // $("#add_user").select2();
});


$(function(){          
  var items="";
      $.getJSON(url+"Common/getAllUsers",function(list){
      items+="<option value=''> --Select Users --</option>";
      $.each(list,function(index,itemlist){
      $.each(itemlist,function(index,item) {
      items+="<option value='"+item.id+"'>"+item.first_name+" "+item.last_name+"("+item.designation+")</option>";
        });
      });
      $("#search_business_createdby").html(items);
    });
       $("#search_business_createdby").select2();
});


$(function(){          
  var items="";
      $.getJSON(url+"Common/getStatus",function(list){
      items+="<option value=''>--Select Status --</option>";
      $.each(list,function(index,itemlist){
      $.each(itemlist,function(index,item) {
      items+="<option value='"+item.id+"'>"+item.status_value+"</option>";
        });
      });
      $("#search_business_status").html(items);
    });
       // $("#add_user").select2();
});


$(function(){          
  var items="";

      $.getJSON(url+"Common/getDesignation",function(city){
      items+="<option value=''>--Select Designation--</option>";
      $.each(city,function(index,itemlist) {
      $.each(itemlist,function(index,item) {
      items+="<option value='"+item.id+"'>"+item.designation+"</option>";
        });
      });
      $("#add_employees_role").html(items);
      $("#edit_employees_role").html(items);
      $("#search_employee_designation").html(items);
  });
});


$(function(){          
  var items="";
      $.getJSON(url+"Common/getSubpackages",function(sublist_name){
      items+="<option value=''>--Select Packages --</option>";
      $.each(sublist_name,function(index,itemlist) {
      $.each(itemlist,function(index,item) {
      items+="<option value='"+item.id+"'>"+item.sublist_name+"</option>";
        });
      });
      $("#add_package_campaign").html(items);
      $("#edit_package_campaign").html(items);
   });
}); 


$(function(){          
  var items=""

      $.getJSON(url+"Common/getCategories",function(category_name){
      items+="<option value=''>--Select Category--</option>";
      $.each(category_name,function(index,itemlist) {
      $.each(itemlist,function(index,item) {
      items+="<option value='"+item.id+"'>"+item.category_name+"</option>";
        });
      });
      $("#add_demowebsites_category").html(items);
      $("#edit_demowebsites_category").html(items);
      $("#add_keywords_category").html(items);
      $("#edit_keywords_category").html(items);

      $("#search_business_website").html(items);
      $("#search_editbusiness_website").html(items);

      $("#search_demo_website").html(items);
      $("#search_editbusiness_keyword").html(items);
       $("#search_demo_keyword").html(items);
      $("#search_bemail_website").html(items);

      $("#search_packages_website").html(items);
  });

  $("#search_business_website").select2();
  $("#search_editbusiness_website").select2();
  $("#search_demo_website").select2();
  $("#search_bemail_website").select2();
  $("#search_editbusiness_keyword").select2();
  $("#search_demo_keyword").select2();
  $("#search_demo_keyword").select2();

});





$(function(){          
  var items="";
  
      $.getJSON(url+"Common/getStatusWithOutDealClosed",function(status){
      items+="<option value=''>--Select Status--</option>";
      $.each(status,function(index,itemlist) {
      $.each(itemlist,function(index,item) {
      items+="<option value='"+item.id+"'>"+item.status_value+"</option>";
        });
      });
      $("#add_business_status").html(items);
      $("#add_packages_status").html(items);
      $("#edit_business_status").html(items);
      $("#edit_status").html(items);
      $("#change_status").html(items);
      $("#market_change_status").html(items);
      $("#market_add_packages_status").html(items);
      $("#market_edit_business_status").html(items);
      $("#market_lead_change_status").html(items);
      $("#market_lead_add_packages_status").html(items);
      $("#market_lead_edit_business_status").html(items);
      $("#market_lead_edit_business_status").html(items);
      $("#add_paymentpending_status").html(items);
  });
});

// $(function(){          
//   var items="";
  
//       $.getJSON(url+"Common/getStatus",function(status){
//       items+="<option value=''>--Select Status--</option>";
//       $.each(status,function(index,itemlist) {
//       $.each(itemlist,function(index,item) {
//       items+="<option value='"+item.id+"'>"+item.status_value+"</option>";
//         });
//       });
//       $("#change_status").html(items);
//   });
// });



function getState(selectedValue){
   var cityId=selectedValue.value;
   var items="";
	
	    $.getJSON(url+"Common/getState/"+cityId,function(profilestate){
	    items+="<option value=''>---Select State---</option>";
	    $.each(profilestate,function(index,itemlist) {
	   	$.each(itemlist,function(index,item) {
			items+="<option value='"+item.state_id+"'>"+item.state_name+"</option>";
		    });
	    });
      $("#add_business_state").html(items);
      $("#edit_business_state").html(items);
      $("#add_business_gststate").html(items);
      $("#edit_business_gststate").html(items);
      $("#add_employees_state").html(items);
      $("#edit_employees_state").html(items);
      $("#market_edit_business_state").html(items);
      $("#market_edit_business_gststate").html(items);
      $("#market_lead_edit_business_state").html(items);
      $("#market_lead_edit_business_gststate").html(items);
      $("#add_gform_state").html(items);
  });
}
$(function(){          
  var items="";

      $.getJSON(url+"Common/getCity",function(city){
      items+="<option value=''>--Select City--</option>";
      $.each(city,function(index,itemlist) {
      $.each(itemlist,function(index,item) {
      items+="<option value='"+item.cityid+"'>"+item.cityname+"</option>";
        });
      });
      $("#add_business_city").html(items);
      $("#edit_business_city").html(items);
      $("#add_mapping_city").html(items);
      $("#edit_mapping_city").html(items);
      $("#add_employees_city").html(items);
      $("#edit_employees_city").html(items);
      $("#search_business_city").html(items);
      $("#search_employee_city").html(items);
      $("#search_telemarketing_business_city").html(items);
      $("#search_marketinglead_business_city").html(items);
      $("#market_edit_business_city").html(items);
      $("#market_lead_edit_business_city").html(items);
      $("#add_gform_city").html(items);
  });
      $("#search_telemarketing_business_city").select2();
      $("#search_marketinglead_business_city").select2();
      $("#add_mapping_city").select2();
      $("#edit_mapping_city").select2();
});

$(function(){				   
	var items="";
	    $.getJSON(url+"Common/getState",function(profilestate){
	    items+="<option value=''>---Select State---</option>";
	    $.each(profilestate,function(index,itemlist) {
	   	$.each(itemlist,function(index,item) {
			items+="<option value='"+item.state_id+"'>"+item.state_name+"</option>";
		    });
	    });
      $("#add_business_state").html(items);
      $("#edit_business_state").html(items);
      $("#add_business_gststate").html(items);
      $("#edit_business_gststate").html(items);
      $("#add_employees_state").html(items);
      $("#edit_employees_state").html(items);
      $("#market_edit_business_state").html(items);
      $("#market_edit_business_gststate").html(items);
      $("#market_lead_edit_business_state").html(items);
      $("#market_lead_edit_business_gststate").html(items);
      $("#add_gform_state").html(items);
	});
});






$(function(){          
  var items="";
  var edititems="";
  var paymentpedingitems="";
      $.getJSON(url+"Common/getPaymenttype",function(profilestate){
      items+=" ";
      edititems+=" ";
      paymentpedingitems+=" ";
      $.each(profilestate,function(index,itemlist) {
      $.each(itemlist,function(index,item) {
      items+='<li class="nav-item"><label> <input type="radio"  value='+item.id+' id="add_business_payment_mode" name="add_business_payment_mode"  onchange="showPaymentmode(this)" style="display: inline;"> <span class="form-label"> '+item.paymenttype_name+' </span> </label> </li>';
      edititems+='<li class="nav-item"><label> <input type="radio"  value='+item.id+' id="add_newbusiness_payment_mode" name="add_newbusiness_payment_mode"  onchange="shownewPaymentmode(this)" style="display:inline;"> <span class="form-label"> '+item.paymenttype_name+' </span> </label> </li>';
      paymentpedingitems+='<li class="nav-item"><label> <input type="radio"  value='+item.id+' id="add_paymentpending_payment_mode" name="add_paymentpending_payment_mode"              onchange="showpaymentpendingPaymentmode(this)" style="display: inline;"> <span class="form-label"> '+item.paymenttype_name+' </span> </label> </li>';
         });
      });
     $("#addpackagespaymentmode").html(items);
     $("#addbusinesspaymentmode").html(edititems);
     $("#addpaymentpendingpaymentmode").html(paymentpedingitems);
     // $("#receiptpayment").html(items);
     // $("#printreceiptpayment").html(items);
  });
});


$(function(){          
  var items="";
  var bitems="";

      $.getJSON(url+"Common/getCampaignlist",function(campaignlist){
      items+=" ";
      bitems+=" ";
      $.each(campaignlist,function(index,itemlist) {
      $.each(itemlist,function(index,item) {
      
      items+='<div class="col-md-4"><div class="form-group">  <label> <input type="checkbox"  value='+item.id+' data-cname="'+item.campaign_name+'" data-camount="'+item.campaign_amount+'" id="add_business_campaign" name="add_business_campaign[]" > <span style="text-align:center;"> <img src="'+url+item.campaign_photo+ '" width="100"  height="80" alt=" photo" /> <p class="form-label"> '+item.campaign_name+' </p> <div>Amount: '+item.campaign_amount+' </div>  </span> </label> </div></div>';

      bitems+='<div class="col-md-4"><div class="form-group">  <label> <input type="checkbox"  value='+item.id+' data-newcname="'+item.campaign_name+'" data-newcamount="'+item.campaign_amount+'" id="add_newbusiness_campaign" name="add_newbusiness_campaign[]" > <span style="text-align:center;"> <img src="'+url+item.campaign_photo+ '" width="100"  height="80" alt=" photo" /> <p class="form-label"> '+item.campaign_name+' </p> <div>Amount: '+item.campaign_amount+' </div>  </span> </label> </div></div>';
          });
      });
      $("#addcampaignlist").html(items);
      $("#addbusinesscampaignlist").html(bitems);
      
  });
});



$(function(){          
  var items="";
  var bitems="";

      $.getJSON(url+"Common/getCampaignERPlist",function(campaignlist){
      items+=" ";
      bitems+=" ";
      $.each(campaignlist,function(index,itemlist) {
      $.each(itemlist,function(index,item) {
      
      items+='<div class="col-md-4"><div class="form-group">  <label> <input type="checkbox"  value='+item.id+' id="add_business_campaign" name="add_business_campaign[]" data-cname="'+item.campaign_name+'" data-camount="'+item.campaign_amount+'" > <span style="text-align:center;"> <img src="'+url+item.campaign_photo+ '" width="100"  height="80" alt=" photo" /> <p class="form-label"> '+item.campaign_name+' </p> <div>Amount: '+item.campaign_amount+' </div>  </span> </label> </div></div>';

      bitems+='<div class="col-md-4"><div class="form-group">  <label> <input type="checkbox"  value='+item.id+' id="add_newbusiness_campaign" name="add_newbusiness_campaign[]" data-newcname="'+item.campaign_name+'" data-newcamount="'+item.campaign_amount+'" > <span style="text-align:center;"> <img src="'+url+item.campaign_photo+ '" width="100"  height="80" alt=" photo" /> <p class="form-label"> '+item.campaign_name+' </p> <div>Amount: '+item.campaign_amount+' </div>  </span> </label> </div></div>';

          });
      });
      $("#addcampaignERPlist").html(items);
      $("#addbusinesscampaignERPlist").html(bitems);
  });
});



$(function(){          
  var items="";
  var itemsb="";
  var edititems="";

      $.getJSON(url+"Common/getPackagelist",function(packagelist){
      items+=" ";
      itemsb+=" ";
      edititems+=" ";
      $.each(packagelist,function(index,itemlist) {
      $.each(itemlist,function(index,item) {
      
  var i;
  var values = item.sublist_name;
  var subname = values.split(',');
  var n =subname.length;
  var sname ="";

for(i=0;i<n;i++) {
   sname+= "<div class='subpackage'>"+subname[i]+"</div>"
   }
      items+='<div class="col-md-6 col-xl-4 mt-2 mb-2 packageslist"><div class="card border-success border card-packages"> <div class="text-center pt-3 pb-2 card-packagehead"><h3>'+item.package_name+'</h3><h4 class="font-weight-normal mt-2 mb-2">Rs.'+item.package_amount+'</h4></div> <div ><span> '+sname+'</span></div> <p class="mt-3 mb-3 plan-cost text-gray text-center"> <label> <input type="checkbox"  value='+item.id+'  id="add_business_package" name="add_business_package[]" data-pname="'+item.package_name+'" data-pamount="'+item.package_amount+'"> Select Package </label></div></div>';

      itemsb+='<div class="col-6 col-xl-6 mt-2 mb-2 packageslist"><div class="card border-success border card-packages "> <div class="text-center pt-3 pb-2 "><h3>'+item.package_name+'</h3><h4 class="font-weight-normal mt-2 mb-2">Rs.'+item.package_amount+'</h4></div> <div ><span> '+sname+'</span></div> <p class="mt-3 mb-3 plan-cost text-gray text-center"> <label> <input type="checkbox"  value='+item.id+'  id="add_newbusiness_package" name="add_newbusiness_package[]" data-newpname="'+item.package_name+'" data-newpamount="'+item.package_amount+'"> Select Package </label></p></div></div>';
    });
     
  });
  $("#addpackagelist").html(items);
   $("#addbusinesspackagelist").html(itemsb);
  });
});

//============== demo websites start ====//

viewDemowebsites();   
        function viewDemowebsites(){
            $.ajax({
                type  : 'GET',
                url   : url+"Common/SearchWebsitesForBusinessList",
                async : true,
                dataType : 'json',
                success : function(result){
     if(result.success==true){
        viewDemowebsitesList(result.data);
      
              }        
                }
            });
        }

  function viewDemowebsitesList(demowebsites){
       var items = "";
       var edititems = "";
       var i;
       var n = demowebsites.length;

    for(var i=0; i<n; i++){
        items+='<div class="col-md-4 col-6 form-group"><div class="demoweb card"><img src="'+url+demowebsites[i].web_photo+'" alt="web image" class="image"><div class="container"><h6 class="p-2">'+demowebsites[i].web_name+'</h6></div><div class="overlay"><div class="text"><a  href="'+demowebsites[i].web_url+'" class="btn btn-info btn-rounded btn-fw mb-3" target="_blank">Live Demo</a><a  href="'+demowebsites[i].web_url+'" class="btn btn-light btn-rounded btn-fw" target="_blank">Preview</a></div></div></div></div>';
     }    

        $("#demowebsitesbusiness").html(items);;
  
  }

function searchdemowebsitesByCategory(search_website){
  var search_business_website = search_website;
 var items =" ";
   $.ajax({
       type:"POST",
       url:url+"Common/SearchWebsitesForBusinessList",
    dataType: 'json',
    data:{search_business_website:search_business_website},
    dataType: 'json',

 success: function(result){
      
      if(result.success==true){
        
        viewDemowebsitesList(result.data);  
      }
  else if(result.success==false){
        $('#search_business_website-msg').hide().fadeIn('').delay(1000).fadeOut(2200);
        $( "#search_business_website-msg" ).html("<div class='alert alert-danger'>"+result.message+"</div>");
      }
    },
    
    failure: function (result){
      $('#search_business_website-msg').hide().fadeIn('slow').delay(1000).fadeOut(2200);
      $( "#search_business_website-msg" ).html("<div class='alert alert-danger'>Some thing went wrong try again ...</div>");      
    } 
         
      });

}
//============== demo websites end =====//
var map;
var marker;

function myMap() {
if (navigator.geolocation) {

    navigator.geolocation.getCurrentPosition(function (p) {

        var LatLng = new google.maps.LatLng(p.coords.latitude, p.coords.longitude);

        var mapOptions = {

            center: LatLng,
    
            zoom: 13,

            draggable: true,

            mapTypeId: google.maps.MapTypeId.ROADMAP



        };

        var map = new google.maps.Map(document.getElementById("dvMap"), mapOptions);

        var marker = new google.maps.Marker({

            position: LatLng,

            draggable: true,

            map: map,
    
            title: "<div style = 'height:60px;width:200px'><b>Your location:</b><br />Latitude: " + p.coords.latitude + "<br />Longitude: " + p.coords.longitude

        });

       

        google.maps.event.addListener(marker, "click", function (e) {

            var infoWindow = new google.maps.InfoWindow();

            infoWindow.setContent(marker.title);

            infoWindow.open(map, marker);

        });
/*var geocoder;
      google.maps.event.addListener(marker, 'dragend', function() {

geocoder.geocode({'latLng': marker.getPosition()}, function(results, status) {
if (status == google.maps.GeocoderStatus.OK) {
if (results[0]) {
//$('#address').val(results[0].formatted_address);
$('#add_business_currentlat').val(p.coords.latitude);
$('#add_business_currentlat').val(p.coords.longitude);
infowindow.setContent(results[0].formatted_address);
infowindow.open(map, marker);
}
}
});
});*/     

         //alert(p.coords.latitude+" , "+p.coords.longitude);

    document.getElementById("add_business_currentlat").value = p.coords.latitude;

    document.getElementById("add_business_currentlag").value = p.coords.longitude;

    })  ;
    
  
    

} else {

    alert('Geo Location feature is not supported in this browser.');

}

  }

BusinessviewListData();   
function BusinessviewListData(){
    $.ajax({
    type : 'GET',
    url : url+"Common/SearchBusinessList",
    async : true,
    dataType : 'json',
    success : function(result){
      if(result.success===true){
        BusinessViewList(result.data,result.role);
      } 

    }
    });
}

 function BusinessViewList(businesslist,roles){
       var role=roles ;
   if ( $.fn.DataTable.isDataTable('#businesstable')) {
         $('#businesstable').DataTable().destroy();
         }  
         $('#businesstable tbody').empty();
          var data=businesslist;
         var table = $('#businesstable').DataTable({
         paging: true,
         searching: true,
         columns: [
      {data: 'id',title: 'S No.'},
      {data: 'business_id',title:'Company ID'},
      {data: 'company_name',title:'Company Name'},
      {data: 'area',title: 'Area'},
      {data: 'cityname',title: 'City Name'},
      {data: 'state_name',title: 'State Name'}, 
      {data: 'created_name',title: 'Taken By Name'},
      {data: 'status_value',title:'Status'},
      {data: null,
           'title' : 'Action',
           "sClass" : "center",
           "width":"20%",
           mRender: function (data, type, row) {
           if(role=="Marketing-Lead"){
             return '<button class="btn btn-info btn-sm mt-2 status_edit" data-toggle="modal" id="status_edit" data-target="#EditstatusModal" title="Status Edit"><a data-businessid="'+data.id+'" data-businessname="' +data.company_name+ '" style="color:#ffffff"> <i class="mdi mdi-pencil-box"></i> </a></button> &nbsp;                                                                                                      <button class="btn btn-info btn-sm mt-2  editbusiness"  id="businessdata_edit" title="Business Edit" style="color:#0066ff"><a data-businessid="'+data.id+'" data-businessname="' +data.company_name+ '"  style="color:#ffffff"> <i class="mdi mdi-grease-pencil"></i> </a></button>&nbsp;                                                                           <button class="btn btn-info btn-sm mt-2 selectedpackages" title="Select Package"><a data-businessid="'+data.id+'" data-businessname="' +data.company_name+ '"style="color:#ffffff" data-businessstate_id="'+data.state_id+'" > <i class="mdi mdi-package-variant" data-name="mdi-package-variant"></i> </a></button>&nbsp;                                                                                         <button class="btn btn-primary btn-sm mt-2 listofbusiness" title="Payment History"><a data-businessid="'+data.id+'" data-businessname="' +data.company_name+ '" style="color:#ffffff" > <i class="mdi mdi-wallet" data-name="mdi-package-variant"></i> </a></button>'

          }else if(role=="Marketing"){
               return '<button class="btn btn-info btn-sm mt-2 status_edit" data-toggle="modal" id="status_edit" data-target="#EditstatusModal" title="Status Edit"><a data-businessid="'+data.id+'" data-businessname="' +data.company_name+ '" style="color:#ffffff"> <i class="mdi mdi-pencil-box"></i> </a></button> &nbsp;                                                                                                    <button class="btn btn-info btn-sm mt-2 selectedpackages" title="Select Package"><a data-businessid="'+data.id+'" data-businessname="' +data.company_name+ '"style="color:#ffffff" data-businessstate_id="'+data.state_id+'" > <i class="mdi mdi-package-variant" data-name="mdi-package-variant"></i> </a></button>&nbsp;                                                                                       <button class="btn btn-primary btn-sm mt-2 listofbusiness" title="Payment History"><a data-businessid="'+data.id+'" data-businessname="' +data.company_name+ '" style="color:#ffffff" > <i class="mdi mdi-wallet" data-name="mdi-package-variant"></i> </a></button>'

          }else if(role=="Tele-Marketing"){
              return '<button class="btn btn-info btn-sm mt-2 status_edit" data-toggle="modal" id="status_edit" data-target="#EditstatusModal" title="Status Edit"><a data-businessid="'+data.id+'" data-businessname="' +data.company_name+ '" style="color:#ffffff"> <i class="mdi mdi-pencil-box"></i> </a></button> &nbsp;                                                                                                                       <button class="btn btn-info btn-sm mt-2 selectedpackages" title="Select Package"><a data-businessid="'+data.id+'" data-businessname="' +data.company_name+ '"style="color:#ffffff" data-businessstate_id="'+data.state_id+'" > <i class="mdi mdi-package-variant" data-name="mdi-package-variant"></i> </a></button>&nbsp;                                                                                        <button class="btn btn-primary btn-sm mt-2 listofbusiness" title="Payment History"><a data-businessid="'+data.id+'" data-businessname="' +data.company_name+ '" style="color:#ffffff" > <i class="mdi mdi-wallet" data-name="mdi-package-variant"></i> </a></button>'
          } else{
   
       return '<button class="btn btn-info btn-sm mt-2 status_edit" data-toggle="modal" id="status_edit" data-target="#EditstatusModal" title="Status Edit"><a data-businessid="'+data.id+'" data-businessname="' +data.company_name+ '" style="color:#ffffff"> <i class="mdi mdi-pencil-box"></i> </a></button> &nbsp;<button class="btn btn-info btn-sm mt-2  editbusiness" id="businessdata_edit" title="Business Edit" style="color:#0066ff"><a data-businessid="'+data.id+'" data-businessname="' +data.company_name+ '"  style="color:#ffffff"> <i class="mdi mdi-grease-pencil"></i> </a></button>&nbsp;        <button class="btn btn-danger btn-sm mt-2 business_delete" title="Business Delete" ><a data-businessid="'+data.id+'" data-businessname="' +data.company_name+ '" style="color:#ffffff" > <i class="mdi mdi-delete"></i> </a></button>&nbsp;                                                                      <button class="btn btn-info btn-sm mt-2 selectedpackages" title="Select Package"><a data-businessid="'+data.id+'" data-businessname="' +data.company_name+ '"style="color:#ffffff" data-businessstate_id="'+data.state_id+'" > <i class="mdi mdi-package-variant" data-name="mdi-package-variant"></i> </a></button>&nbsp;                             <button class="btn btn-primary btn-sm mt-2 listofbusiness" title="Payment History"><a data-businessid="'+data.id+'" data-businessname="' +data.company_name+ '" style="color:#ffffff" > <i class="mdi mdi-wallet" data-name="mdi-package-variant"></i> </a></button>'  }
           } }] 


       });

 
table.rows.add(data).draw();
 
 }

$('[data-toggle="modal"]').tooltip();

$(document).on('click', '.status_edit a', function(e){
 var id= $(this).attr("data-businessid");
 $.ajax({
    type: "GET",
    url:url+'Common/editStatusByid/'+id,
    dataType: 'json',
  success:function(result){
      if(result.success===true)
      { 
        
        // alert(result.data);
       //              $("#status_closed").empty();
       //        for(var i=0; i < result.data.length; i++){
       //        $('#status_closed').append($("<option></option>")
       //              .attr("value",result.data[i].id)
       //              .text(result.data[i].status_value).prop("selected", true)); 
       //         }

       //  
       // $('#change_status_form #change_company_name').text(result.data[0].company_name);
        
       
       //  $("#status_closed").append("<option value='"+result.status[0].id+"'>"+result.status[0].status_value+"</option>");
        
        $('#change_status_form #change_status_id').val(id);
       $('#change_status_form #change_status').val(result.data[0].business_status_id).prop("selected", true);
    
       }else{
            alert('request failed', 'error');
      }

    },
   
 
 fail:function(result){
      
      alert('Information request failed: ' + textStatus, 'error');
    }


});

});

 $("#updatestatus").click(function(){
    if(!$("#change_status_form").valid())
   {
     return false;
   }
  
  var formData = new FormData($("#change_status_form")[0] );
   $.ajax({
       type:"POST",
       url:url+"Common/updateStatusByid",
    dataType: 'json',
    data:formData,
    contentType: false, 
    cache: false,      
    processData:false,

 success: function(result){
      
      if(result.success===true){
      
        $('#citymapping-editmsg').hide().fadeIn('slow').delay(1000).fadeOut(2200);    
          $("#citymapping-editmsg" ).html("<div class='alert alert-success'>"+result.message+"</div>");

           $("#change_status_form")[0].reset();
            setTimeout(function(){
               $('#EditstatusModal').modal('hide');
                }, 5000); 

       BusinessviewListData();

   }
  else if(result.success===false){
        $('#citymapping-editmsg').hide().fadeIn('').delay(1000).fadeOut(2200);
        $( "#citymapping-editmsg" ).html("<div class='alert alert-danger'>"+result.message+"</div>");
      }
    },
    
    failure: function (result){

      $('#citymapping-editmsg').hide().fadeIn('slow').delay(1000).fadeOut(2200);
      $( "#citymapping-editmsg" ).html("<div class='alert alert-danger'>Some thing went wrong try again ...</div>");      
    } 
         
      });


});



$("#showaddbusiness").click(function(){
 $(".listbusiness-class").hide();
 $(".addbusiness-class").show();
});





$(document).on('click', '.editbusiness a', function(e){

 $(".listbusiness-class").hide();
 $(".addbusiness-class").hide();
 $(".editbusiness-class").show();
 var id= $(this).attr("data-businessid");

$.ajax({
    type: "GET",
    url:url+'Common/editBusinessByid/'+id,
    dataType: 'json',
 
  success:function(result){
      if(result.success===true)
      { 

        // alert(result.data[0].company_name);
        // $('#edit_businessname_head').html(result.data[0].company_name);  

        $('#edit_businessdata #edit_business_addid').val(result.data[0].address_id);
        $('#edit_businessdata #edit_business_id').val(result.data[0].id);
        $('#edit_businessdata #edit_business_cname').val(result.data[0].company_name);
        $('#edit_businessdata #edit_business_hno').val(result.data[0].house_no);
        $('#edit_businessdata #edit_business_street').val(result.data[0].street);
        $('#edit_businessdata #edit_business_subarea').val(result.data[0].sub_area);
        $('#edit_businessdata #edit_business_area').val(result.data[0].area);
        $('#edit_businessdata #edit_business_landmark').val(result.data[0].landmark);
        $('#edit_businessdata #edit_business_city').val(result.data[0].city_id).prop("selected", true);
        $('#edit_businessdata #edit_business_state').val(result.data[0].state_id).prop("selected", true);
        
        if(result.data[0].pincode==0){
           var pincode ="";
        }else{
            var pincode =result.data[0].pincode;
        }
        $('#edit_businessdata #edit_business_pincode').val(pincode);

         $('#edit_businessdata #edit_business_pname').val(result.data[0].person_name);
         $('#edit_businessdata #edit_business_designation').val(result.data[0].person_designation);
         $('#edit_businessdata #edit_business_landlineno').val(result.data[0].landline_no);
         $('#edit_businessdata #edit_business_mobileno').val(result.data[0].mobile_no);
         $('#edit_businessdata #edit_business_altnemobileno').val(result.data[0].alt_mobile_no);
         $('#edit_businessdata #edit_business_email').val(result.data[0].email);

        $('#edit_businessdata #edit_business_gstcname').val(result.data[0].gst_company_name);
        $('#edit_businessdata #edit_business_cgstcname').val(result.data[0].gst_company_name);
        $('#edit_businessdata #edit_business_gstno').val(result.data[0].gst_number);
        $('#edit_businessdata #edit_business_cgstno').val(result.data[0].gst_number);
        $('#edit_businessdata #edit_business_gststate').val(result.data[0].gst_state);
         if(result.data[0].gst_pincode==0){
           var gst_pincode ="";
        }else{
            var gst_pincode =result.data[0].gst_pincode;
        }
        $('#edit_businessdata #edit_business_gstpincode').val(gst_pincode);
        $('#edit_businessdata #edit_business_gstpanno').val(result.data[0].gst_pan_no);
        $('#edit_businessdata #edit_business_gstaddress').val(result.data[0].gst_address);
        $('#edit_businessdata #edit_business_status').val(result.data[0].business_status_id).prop("selected", true);


        $('#edit_businessdata #edit_business_website').val(result.data[0].website_url);
        $('#edit_businessdata #edit_business_facebook').val(result.data[0].facebook_url);
        $('#edit_businessdata #edit_business_twitter').val(result.data[0].twitter_url);
        $('#edit_businessdata #edit_business_youtube').val(result.data[0].youtube_url);
        $('#edit_businessdata #edit_business_linkedin').val(result.data[0].linkedin_url);
        $('#edit_businessdata #edit_business_instagram').val(result.data[0].instagram_url);

        $('#edit_businessdata #edit_business_owner1name').val(result.editowner[0].owner_name);
        $('#edit_businessdata #edit_business_owner1role').val(result.editowner[0].owner_role);
         if(result.editowner[0].owner_mobile==0){
           var owner_mobile ="";
        }else{
            var owner_mobile =result.editowner[0].owner_mobile;
        }
        $('#edit_businessdata #edit_business_owner1mobile').val(owner_mobile);
        $('#edit_businessdata #edit_business_owner1email').val(result.editowner[0].owner_email);

        $('#edit_businessdata #edit_business_owner2name').val(result.editowner[1].owner_name);
        $('#edit_businessdata #edit_business_owner2role').val(result.editowner[1].owner_role);
         if(result.editowner[1].owner_mobile==0){
           var owner_mobile1 ="";
        }else{
            var owner_mobile1 =result.editowner[1].owner_mobile;
        }
        $('#edit_businessdata #edit_business_owner2mobile').val(owner_mobile1);
        $('#edit_businessdata #edit_business_owner2email').val(result.editowner[1].owner_email);
      
         

         $('#edit_businessdata #edit_business_lat').val(result.data[0].latitude);
         $('#edit_businessdata #edit_business_long').val(result.data[0].longitude);
// alert(result.data[0].longitude);
    var latitude=result.data[0].latitude;
    var longitude=result.data[0].longitude;
   var myLatLng = {lat:latitude, lng:longitude};
   var map = new google.maps.Map(document.getElementById('editdvMap'), {
     zoom: 4,
     center: myLatLng
   });

   var marker = new google.maps.Marker({
     position: myLatLng,
     map: map
   });
   if(result.data[0].photo!=null){
     $("#businessimage").html('<img src="'+url+result.data[0].photo+ '" width="200px"  height="100px" alt=" photo" />');
   }else{
    $("#businessimage").html('<img src="'+url+'assets/images/no_image.png" width="200px"  height="100px" alt=" photo" />')
   }
      }else{
            alert('request failed', 'error');
      }

    },
   
 
 fail:function(result){
      alert('Information request failed: ' + textStatus, 'error');
    }

});

});

var businesseditform = $("#edit_businessdata");
businesseditform.validate({
    errorPlacement: function errorPlacement(error, element) { element.before(error); },
    rules: {
      edit_business_city :"required",
      edit_business_state :"required",
      edit_business_cname :"required",
      edit_business_street:"required", 
      edit_business_area:"required",
      edit_business_pincode:{number:true,minlength:6, maxlength:6},
      edit_business_pname:"required",
      edit_business_designation:"required",
      edit_business_landlineno:{number:true,minlength:8, maxlength:16},
      edit_business_mobileno:{required:true,number:true, number:true,minlength:10, maxlength:10},
      edit_business_altnemobileno:{minlength:10, maxlength:10},
      edit_business_condition:"required",
      edit_business_email:{required:true,email: true },
      edit_business_cgstcname: {equalTo: "#edit_business_gstcname"},
      edit_business_cgstno: {equalTo: "#edit_business_gstno"},
      edit_business_debitcardno:{number:true,minlength:5, maxlength:18},
      edit_business_creditcardno:{number:true,minlength:5, maxlength:18},
      edit_business_accountno:{number:true,minlength:5, maxlength:20},
      edit_business_caccountno: {number:true,minlength:5, maxlength:20,equalTo: "#edit_business_accountno"},
      edit_business_cacholdername: { equalTo: "#edit_business_acholdername"},
      // edit_business_owner1name:"required",
      // edit_business_owner1role:"required",
      edit_business_owner1mobile:{number:true,minlength:10, maxlength:10},
      edit_business_owner1email:{email: true },
      edit_business_owner2mobile:{minlength:10, maxlength:10},
      edit_business_owner2email:{email: true },
      // edit_business_status:"required",
      

    }
});

businesseditform.children("div").steps({
    headerTag: "h3",
    bodyTag: "section",
    transitionEffect: "slideLeft",
    onStepChanging: function (event, currentIndex, newIndex)
    {
        businesseditform.validate().settings.ignore = ":disabled,:hidden";
        return businesseditform.valid();
    },
    onFinishing: function (event, currentIndex)
    {
        var result = $('ul[aria-label=Pagination]').children().find('a');
        $(result).each(function ()  { 
           if ($(this).text() == 'Finish') {
               $(this).attr('disabled', true);
               $(this).css('background', 'green');
           } 
        });
        businesseditform.validate().settings.ignore = ":disabled";
        return businesseditform.valid();
    },
    onFinished: function (event, currentIndex)
    {

    var formData = new FormData($("#edit_businessdata")[0] );
     $.ajax({
      type:"POST",
    url:url+"Common/updateBusinessData",
    dataType: 'json',
    data:formData,
    contentType: false, 
    cache: false,      
    processData:false,
    beforeSend: function(){
    // Show image container
    $(".loader").show();
},
     

      success: function(result){
      if(result.success==true){
        $('#businessdata-editmsg').hide().fadeIn('slow').delay(1000).fadeOut(2200);   
        $( "#businessdata-editmsg" ).html("<div class='alert alert-success'>"+result.message+"</div>");
        $('#edit_businessdata')[0].reset();
        window.setTimeout(function(){location.reload()},3000)
      }
      else{
        $('#businessdata-editmsg').hide().fadeIn('').delay(1000).fadeOut(2200);
        $( "#businessdata-editmsg" ).html("<div class='alert alert-danger'>"+result.message+"</div>");
      }
    },
      complete:function(){
    // Hide image container
    $(".loader").hide();
}, 
    failure: function (result){

      $('#businessdata-editmsg').hide().fadeIn('slow').delay(1000).fadeOut(2200);
      $( "#businessdata-editmsg" ).html("<div class='alert alert-danger'>Some thing went wrong try again ...</div>");     
    } 
         
      });

    }
});



$(document).on('click', '.business_delete a', function(e){
 
 var id= $(this).attr("data-businessid");
 var name=$(this).attr("data-businessname");

  // swal({
  //       title: "Are you sure?",
  //       text: "You will not be able to recover "+" "+name ,
  //       type: "warning",
  //       showCancelButton: true,
  //       confirmButtonColor: "#dc3545",
  //       confirmButtonText: "Yes, delete it  !",
  //        closeOnConfirm: false,
  //          },
  // function(isConfirm) {
  //  if (isConfirm) {

    $.ajax({
    type: "GET",
    url:url+'Common/deleteBusinessById/'+id,
    dataType: 'json',
    
  success:function(result){
      if(result.success===true)
      { 
    
    swal("Deleted!", "Your"+" "+ name +" "+"has been deleted.", "success");  

    window.setTimeout(function(){location.reload()},3000)
   
      }else{
            alert('request failed', 'error');
      }

    },
 
 fail:function(result){
      
      alert('Information request failed: ' + textStatus, 'error');
    }


});

// }else{
//     swal("Cancelled", "Your imaginary file is safe :)", "error");
//   }

        
//     });

    

    });

/* ====== Business delete end ===== */

var businessform = $("#add_businessdata");
var paymentmodeid = $("#add_newbusiness_payment_mode:checked").val();
businessform.validate({
    errorPlacement: function errorPlacement(error, element) { element.before(error); },
    rules: {
      add_business_city :"required",
      add_business_state :"required",
      add_business_cname :"required",
      add_business_street:"required", 
      add_business_area:"required",
      add_business_pincode:{number:true,minlength:6, maxlength:6},
      add_business_pname:"required",
      add_business_designation:"required",
      add_business_landlineno:{number:true,minlength:8, maxlength:16},
      add_business_mobileno:{required:true,number:true,minlength:10, maxlength:10},
      add_business_cmobileno: { number:true,minlength:10, maxlength:10,equalTo: "#add_business_mobileno"},
      add_business_altnemobileno:{number:true,minlength:10, maxlength:10},
      // add_business_photo:"required",
      add_business_condition:"required",
      add_business_email:{required:true,email: true},
      //add_business_cgstcname: {equalTo: "#add_business_gstcname"},
      //add_business_cgstno: {equalTo: "#add_business_gstno"},
      //add_business_accountno:{number:true,minlength:5, maxlength:20},
      //add_business_caccountno: {number:true,minlength:5, maxlength:20,equalTo: "#add_business_accountno"},
      //add_business_cacholdername: { equalTo: "#add_business_acholdername"},
      // add_business_owner1name:"required",
      // add_business_owner1role:"required",
      //add_business_owner1mobile:{number:true,minlength:10, maxlength:10},
      //add_business_owner1email:{email: true },
      //add_business_owner2mobile:{minlength:10, maxlength:10},
      //add_business_owner2email:{email: true },
      add_business_status:"required",

     /* 
       add_business_debitcardno:{required:function (){
            $("#add_newbusiness_payment_mode:checked").val()==2;
          },number:true,minlength:5, maxlength:18},
       add_business_debitcard_expireddate:{required:function(){
          $("#add_newbusiness_payment_mode:checked").val()==2;
        }
        },   
        add_business_creditcardno:{
          required:function (){
            $("#add_newbusiness_payment_mode:checked").val()==3;
          },number:true,minlength:5, maxlength:16
        },
        add_business_creditcard_expireddate :{required:function(){
          $("#add_newbusiness_payment_mode:checked").val()==3;
          }
        },
       add_business_chequeaccountno:{required:function(){
          $("#add_newbusiness_payment_mode:checked").val()==6;
             
          
        },number:true,minlength:2, maxlength:18
        },
       add_business_chequeno:{ required:function(){
          $("#add_newbusiness_payment_mode:checked").val()==6;
        },number:true,minlength:2, maxlength:10},
       add_business_cchequeno:{
          required:function(){
          $("#add_newbusiness_payment_mode:checked").val()==6;
            
        },number:true,minlength:2, maxlength:10,equalTo: "#add_business_chequeno"},
        add_business_cheque_micr:{required:function(){
           $("#add_newbusiness_payment_mode:checked").val()==6;
        },number:true},
       add_business_cheque_photo :{required:function(){
          $("#add_newbusiness_payment_mode:checked").val()==6;
           
        }},
        add_business_chequeissuedate:{required:function(){
          $("#add_newbusiness_payment_mode:checked").val()==6; 
            
        }},
      // add_business_phonepay:{number:true,minlength:5, maxlength:12},
      // add_business_amazonpay:{number:true,minlength:5, maxlength:12},
      // add_business_googlepay:{number:true},
       add_business_cashamount :{required:function(){
          $("#add_newbusiness_payment_mode:checked").val()==1; 
            
        },number:true},
       add_business_cashdate :{required:function(){
          $("#add_newbusiness_payment_mode:checked").val()==1; 
            
        }},
       add_business_personame:{required:function(){
          $("#add_newbusiness_payment_mode:checked").val()==1;
           
        }},
       add_business_placename:{required:function(){
          $("#add_newbusiness_payment_mode:checked").val()==1;
            
        }},
        add_business_neftnumber:{required:function(){
          
          $("#add_newbusiness_payment_mode:checked").val()==7;
          },number:true},*/
    }
});

businessform.children("div").steps({
    headerTag: "h3",
    bodyTag: "section",
    transitionEffect: "slideLeft",
    saveState: false,
    enableFinishButton: true,
    preloadContent: false,
    showFinishButtonAlways: false,
    forceMoveForward: false,
    onStepChanging: function (event, currentIndex, newIndex)
    {   

         var businesskeywordid = $("#add_business_businesskeyword:checked").val();
         searchdemowebsitesByCategory(businesskeywordid);
         var paymentmodeid = $("#add_newbusiness_payment_mode:checked").val();
         var add_business_creditcard_expireddate=$("#add_business_creditcard_expireddate").val();
         var add_business_creditcardno=$("#add_business_creditcardno").val();
         
         if(paymentmodeid==3 && (!add_business_creditcard_expireddate || add_business_creditcard_expireddate.length<=0) && (!add_business_creditcardno ||  add_business_creditcardno.length<=0)){
            alert("Please fill all Credit Card Mode options!!!");
            return false;
         }
         
         var add_business_chequeaccountno=$("#add_business_chequeaccountno").val();
         var add_business_chequeno=$("#add_business_chequeno").val();
         var add_business_cchequeno=$("#add_business_cchequeno").val();
         var add_business_cheque_micr=$("#add_business_cheque_micr").val();
         var add_business_cheque_photo=$("#add_business_cheque_photo").val();
         var add_business_chequeissuedate=$("#add_business_chequeissuedate").val();
         
         if(paymentmodeid==6 && (!add_business_chequeaccountno || add_business_chequeaccountno.length<=0) && (!add_business_chequeno ||  add_business_chequeno.length<=0) && (!add_business_cchequeno || add_business_cchequeno.length<=0) && (!add_business_cheque_micr || add_business_cheque_micr.length<=0) && (!add_business_cheque_photo || add_business_cheque_photo.length<=0) && (!add_business_chequeissuedate || add_business_chequeissuedate.length<=0)){
            alert("Please fill all Cheque Mode options!!!");
            return false;
         }
         
         var add_business_cashamount=$("#add_business_cashamount").val();
         var add_business_cashdate=$("#add_business_cashdate").val();
         var add_business_personame=$("#add_business_personame").val();
         var add_business_placename=$("#add_business_placename").val();
         
         
         if(paymentmodeid==1 && (!add_business_cashamount || add_business_cashamount.length<=0) && (!add_business_cashdate ||  add_business_cashdate.length<=0) && (!add_business_personame ||  add_business_personame.length<=0) && (!add_business_placename ||  add_business_placename.length<=0)){
            alert("Please fill all Cash Mode options!!!");
            return false;
         }
         
         var add_business_debitcardno=$("#add_business_debitcardno").val();
         var add_business_debitcard_expireddate=$("#add_business_debitcard_expireddate").val();
         if(paymentmodeid==2 && (!add_business_debitcardno || add_business_debitcardno.length<=0) && (!add_business_debitcard_expireddate || add_business_debitcard_expireddate.length<=0)){
            alert("Please fill all Debit Card Mode options!!!");
            return false;
         }
          
         var add_business_neftnumber=$("#add_business_neftnumber").val();
         if(paymentmodeid==7 && (!add_business_neftnumber || add_business_neftnumber.length<=0)){
            alert("Please fill all NEFT/IMPS Mode options!!!");
            return false;
         }
           
         if (currentIndex < newIndex)
        {
            // To remove error styles
            $(".body:eq(" + newIndex + ") label.error", businessform).remove();
            $(".body:eq(" + newIndex + ") .error", businessform).removeClass("error");
        }
        //alert(businessform.valid());
        var result = $('ul[aria-label=Pagination]').children().find('a');
        $(result).each(function ()  { 
           if($(this).text() == 'Finish') {
               $(this).attr('disabled', true);
               $(this).css('background', 'green');
               
           }
           });
        
        //alert(currentIndex);
        businessform.validate().settings.ignore = ":disabled,:hidden";
        return businessform.valid();
        // newpaymentmode.validate().settings.ignore = ":disabled,:hidden";
        // return newpaymentmode.valid();
    },
    onFinishing: function (event, currentIndex)
    {
        businessform.validate().settings.ignore = ":disabled";
        return businessform.valid();
        //return true;
    },
    onFinished: function (event, currentIndex)
    {
      //alert('submitted!!!');
     var paymentmodeid = $("#add_newbusiness_payment_mode:checked").val();
         var add_business_creditcard_expireddate=$("#add_business_creditcard_expireddate").val();
         var add_business_creditcardno=$("#add_business_creditcardno").val();
         if(paymentmodeid==3 && (!add_business_creditcard_expireddate || add_business_creditcard_expireddate.length<=0) && (!add_business_creditcardno ||  add_business_creditcardno.length<=0)){
           alert("Please fill all Credit Card Mode options!!!");
            return false;
         }
         
         var add_business_chequeaccountno=$("#add_business_chequeaccountno").val();
         var add_business_chequeno=$("#add_business_chequeno").val();
         var add_business_cchequeno=$("#add_business_cchequeno").val();
         var add_business_cheque_micr=$("#add_business_cheque_micr").val();
         var add_business_cheque_photo=$("#add_business_cheque_photo").val();
         var add_business_chequeissuedate=$("#add_business_chequeissuedate").val();
         
         if(paymentmodeid==6 && (!add_business_chequeaccountno || add_business_chequeaccountno.length<=0) && (!add_business_chequeno ||  add_business_chequeno.length<=0) && (!add_business_cchequeno || add_business_cchequeno.length<=0) && (!add_business_cheque_micr || add_business_cheque_micr.length<=0) && (!add_business_cheque_photo || add_business_cheque_photo.length<=0) && (!add_business_chequeissuedate || add_business_chequeissuedate.length<=0)){
             alert("Please fill all Cheque Mode options!!!");
            return false;
         }
         
         var add_business_cashamount=$("#add_business_cashamount").val();
         var add_business_cashdate=$("#add_business_cashdate").val();
         var add_business_personame=$("#add_business_personame").val();
         var add_business_placename=$("#add_business_placename").val();
         
         //alert(paymentmodeid);
         if(paymentmodeid==1 && (!add_business_cashamount || add_business_cashamount.length<=0) && (!add_business_cashdate ||  add_business_cashdate.length<=0) && (!add_business_personame ||  add_business_personame.length<=0) && (!add_business_placename ||  add_business_placename.length<=0)){
            alert("Please fill all Cash Mode options!!!");
            return false;
         }
         
         var add_business_debitcardno=$("#add_business_debitcardno").val();
         var add_business_debitcard_expireddate=$("#add_business_debitcard_expireddate").val();
         if(paymentmodeid==2 && (!add_business_debitcardno || add_business_debitcardno.length<=0) && (!add_business_debitcard_expireddate || add_business_debitcard_expireddate.length<=0)){
          alert("Please fill all Debit Card Mode options!!!");
            return false;
         }
          
         var add_business_neftnumber=$("#add_business_neftnumber").val();
         if(paymentmodeid==7 && (!add_business_neftnumber || add_business_neftnumber.length<=0)){
           alert("Please fill all Neft/IMPS Mode options!!!");
            return false;
         }
         
     var formData = new FormData($("#add_businessdata")[0] );

     $.ajax({
      type:"POST",
      url:url+"Common/saveBusinessData",
      dataType: 'json',
      data:formData,
      contentType: false, 
      cache: false,      
      processData:false,
beforeSend: function(){
    // Show image container
    $(".loader").show();
},
      success: function(result){
      
      if(result.success==true){

        $('#businessdata-addmsg').hide().fadeIn('slow').delay(1000).fadeOut(2200);   
        $( "#businessdata-addmsg" ).html("<div class='alert alert-success'>"+result.message+"</div>");
        $('#add_businessdata')[0].reset(); 

        window.setTimeout(function(){location.reload()},3000);
       
        }
      else{
        $('#businessdata-addmsg').hide().fadeIn('').delay(1000).fadeOut(2200);
        $( "#businessdata-addmsg" ).html("<div class='alert alert-danger'>"+result.message+"</div>");
      }
    },
   complete:function(){
    // Hide image container
    $(".loader").hide();
}, 
    failure: function (result){

      $('#businessdata-addmsg').hide().fadeIn('slow').delay(1000).fadeOut(2200);
      $( "#businessdata-addmsg" ).html("<div class='alert alert-danger'>Some thing went wrong try again ...</div>");     
    } 
         
      });

    }
});





$(document).ready(function(){

// $("#babu").click(function(){

//           alert("efjefhrh");

// 	});

// function printtabledetails(){

// 	alert("efjefhrh");

// }

 $("#marketing_selectedcity_btn").click(function(){
 var id= $("#marketing_selected_city").val();

    $.ajax({
    type: "GET",
    url:url+'Common/getCityByIdForMarketing/'+id,
    dataType: 'json',
    
  success:function(result){
		
      if(result.success===true)
      { 
        // $('#marketingcity_form #marketing_city_selected').val(result.city_id).prop("selected", true);
				setTimeout('window.location.href = "'+url+'Marketing"; ',100);

                    

      }else{
            alert('request failed', 'error');
      }

    },
 
 fail:function(result){
      
      alert('Information request failed: ' + textStatus, 'error');
    }


});


    });
 


  });



//===== selected campaign start===//





$(document).on('click', '.selectedpackages a', function(e){

 var id= $(this).attr("data-businessid");
 var name=$(this).attr("data-businessname");
 var state_id=$(this).attr("data-businessstate_id");
$("#add_packages_companyname_state_id").val(state_id);
$("#add_packages_companyname").val(id);
$("#cname").html(name);
$(".listbusiness-class").hide();
$(".addpackages-class").show();


   });
 

 $(document).on('click', '.listofbusiness a', function(e){

 var id= $(this).attr("data-businessid");
 var name=$(this).attr("data-businessname");
$("#companyname").html(name);
$(".listbusiness-class").hide();
$(".lisofbusiness-class").show();

$.ajax({
    type: "GET",
    url:url+'Common/listOfBusiness/'+id,
    dataType: 'json',
 beforeSend: function(){
    // Show image container
    $(".loader").show();
},
  success:function(result){
      if(result.success===true)
      { 
         var role=result.role; 

         if ( $.fn.DataTable.isDataTable('#listofbusinesstable')) {
         $('#listofbusinesstable').DataTable().destroy();
         }  
         $('#listofbusinesstable tbody').empty();

         var data=result.data; 
         var table = $('#listofbusinesstable').DataTable({
        
         paging: true,
         searching: true,
         columns: [
      {data: 'id',title: 'Sno'},
      {data: 'package_name',title:'Packages'},
      {data: 'campaign_name',title:'Campaign'},
      {data: 'gstgrand_total_amount',title:'Grand Total'},
      {data: 'created_on',title:'Date'},
      {data: 'status',title:'Project Status'},
      {data: null,
          'title' : 'Action',
          "sClass" : "center",
          mRender: function (data, type, row) {
           if(role=="Admin"){
               return '<button class="btn btn-primary btn-sm business_invoice"  id="business_invoice" title="Invoice"><a data-selectedid="'+data.id+'" data-selectedname="' +data.company_name+ '" style="color:#FFFFFF;"><i class="mdi mdi-file-document"></i></a></button>&nbsp;                                                                       <button class="btn btn-info btn-sm business_receipt"  id="business_receipt" title="Receipt" ><a data-selectedid="'+data.id+'" data-selectedname="' +data.company_name+ '" style="color:#FFFFFF;"><i class="mdi mdi-file-document"></i></a></button>&nbsp;                                                                       <button class="btn btn-info btn-sm mt-2 project_status_edit" data-toggle="modal" id="project_status_edit" data-target="#projectEditstatusModal" title="Project Status Edit"><a data-businessid="'+data.id+'" data-businessname="' +data.company_name+ '" style="color:#ffffff"> <i class="mdi mdi-pencil-box"></i> </a></button> &nbsp;                                                                                             <button class="btn btn-danger btn-sm business_payment_pending"  id="business_payment_pending" title="Payment Pending" ><a data-selectedid="'+data.id+'" data-selectedname="' +data.company_name+ '" style="color:#FFFFFF;"><i class="mdi mdi-file-document"></i></a></button>&nbsp;'
             }else{
               return '<button class="btn btn-primary btn-sm business_invoice"  id="business_invoice" title="Invoice"><a data-selectedid="'+data.id+'" data-selectedname="' +data.company_name+ '" style="color:#FFFFFF;"><i class="mdi mdi-file-document"></i></a></button>&nbsp;<button class="btn btn-info btn-sm business_receipt"  id="business_receipt" title="Receipt" ><a data-selectedid="'+data.id+'" data-selectedname="' +data.company_name+ '" style="color:#FFFFFF;"><i class="mdi mdi-file-document"></i></a></button>&nbsp; <button class="btn btn-danger btn-sm business_payment_pending"  id="business_payment_pending" title="Payment Pending" ><a data-selectedid="'+data.id+'" data-selectedname="' +data.company_name+ '" style="color:#FFFFFF;"><i class="mdi mdi-file-document"></i></a></button>&nbsp;'
           }

        } }
     ]
   
 });

table.rows.add(data).draw();
       
      }else{
            alert('request failed', 'error');
      }

    },
   
  complete:function(){
    // Hide image container
    $(".loader").hide();
}, 
 fail:function(result){
      
      alert('Information request failed: ' + textStatus, 'error');
    }

});

});



 $(document).on('click', '.business_invoice a', function(e){
 var id= $(this).attr("data-selectedid");
 var name=$(this).attr("data-selectedname");
 $(".lisofbusiness-class").hide();

$.ajax({
    type: "GET",
    url:url+'Common/BusinessInvoice/'+id,
    dataType: 'json',
  success:function(result){
      if(result.success===true)
      { 
          $(".business-invoice-class").show(); 
        
        $('#export_invoice #business_invoice_selectedid').val(result.data[0].business_package_id); 
        $('#business_invoice_id').html(result.data[0].receipt_no);
        $('#business_order_id').html(result.data[0].order_id);
        $('#business_invoice_company_name').html(result.data[0].company_name);
        $('#business_invoice_address').html(result.data[0].address);
        $('#business_invoice_gstno').html(result.data[0].gst_number);

        $('#business_invoice_raisedate').html(result.invoicedata[0].created_on);
        
        $('#business_invoice_duedate').html(result.data[0].duedate);
        $('#business_invoice_subtotal').html(result.data[0].total_amount);
        $('#business_invoice_dicount').html(result.data[0].discount_amount);
        $('#business_invoice_total').html(result.data[0].grand_total_amount);
        if(result.data[0].cgst_amount!=null && result.data[0].sgst_amount!=null){
            $('#business_invoice_cgst').html(result.data[0].cgst_amount);
            $('#business_invoice_sgst').html(result.data[0].sgst_amount);
         
         }else{
             
              $('#business_invoice_cgst').html(0);
              $('#business_invoice_sgst').html(0);

         }
          if( result.data[0].igst_amount!=null){
          $('#business_invoice_igst').html(result.data[0].igst_amount);
         }else{
            $('#business_invoice_igst').html(0);
         }
        $('#business_invoice_grandtotal').html(result.data[0].gstgrand_total_amount);
		    for(var i=0; i<result.campaigndata.length;i++){
		       $("#myTable > tbody").append('<tr class="text-right"><td class="text-left"></td><td class="text-left"> '+result.campaigndata[i][0].campaign_name+'</td><td>1</td><td>'+result.campaigndata[i][0].campaign_amount+'</td><td>'+result.campaigndata[i][0].campaign_amount+'</td></tr>');
		             }             
		    for(var j=0; j<result.packagesdata.length;j++){
		       $("#myTable > tbody").append('<tr class="text-right"><td class="text-left"></td><td class="text-left"> '+result.packagesdata[j][0].package_name+'</td><td>1</td><td>'+result.packagesdata[j][0].package_amount+'</td><td>'+result.packagesdata[j][0].package_amount+'</td></tr>');
		               } 
      }else{
            alert('Invoice Not Generated Please Dealclose Business');
            $(".lisofbusiness-class").show();
         }
    },
   
 fail:function(result){
      alert('Information request failed: ' + textStatus, 'error');
    }

});
});

//===== selected campaign start===//
function myFunction() {
      var total=0;
      var packagetotal=0;
      var campaigntotal=0;
      $('#business_totalamount1').show();
      $('#business_campaignlist1').empty();
        var n = $("#add_newbusiness_campaign:checked").length;
        if (n > 0){
            $("#add_newbusiness_campaign:checked").each(function(){
                //var campaign_id= $(this).val();
                var campainname=$(this).attr("data-newcname");
                var campaignamount=$(this).attr("data-newcamount");
                campaigntotal += Number(campaignamount);

        $('#business_campaignlist1').append('<div class="col-sm-6 col-6 form-group"><label>'+campainname+'</label></div> <div class="col-sm-6 col-6 form-group"><label>'+campaignamount+'</label></div>');   
  
            });

        }

        $('#business_packagelist1').empty();
        var n = $("#add_newbusiness_package:checked").length;
        if (n > 0){
            $("#add_newbusiness_package:checked").each(function(){
                //var campaign_id= $(this).val();
                var packagename=$(this).attr("data-newpname");
                var packageamount=$(this).attr("data-newpamount");
               packagetotal += Number(packageamount); 
        $('#business_packagelist1').append('<div class="col-sm-6 col-6 form-group"><label>'+packagename+'</label></div> <div class="col-sm-6 col-6 form-group"><label>'+packageamount+'</label></div>');   
  
            });
        }
       
     var total=campaigntotal+packagetotal;
    var total= parseFloat(total).toFixed(2); 
     var state_id = $('#add_business_state').val();
     if(state_id==32){
        var cgst=Number(total*9/100);
        var sgst=Number(total*9/100);
        var cgst= parseFloat(cgst).toFixed(2);
        var sgst= parseFloat(sgst).toFixed(2);
        var grandtoatal= parseFloat(total) + parseFloat(cgst)+parseFloat(sgst);
        var grandtoatal= parseFloat(grandtoatal).toFixed(2);
        var gst='<div class="col-sm-6 col-12 form-group"> <label> CGST </label></div> <div class="col-sm-6 col-12 form-group"><label>'+cgst+'</label></div> <div class="col-sm-6 col-12 form-group"> <label> SGST</label></div> <div class="col-sm-6 col-12 form-group"><label>'+sgst+'</label></div>';
       
     }else if(state_id!=32){
       var igst=Number(total*18/100);
      var igst= parseFloat(igst).toFixed(2);
       var grandtoatal= parseFloat(total) + parseFloat(igst);
       var grandtoatal= parseFloat(grandtoatal).toFixed(2);
      gst='<div class="col-sm-6 col-12 form-group"> <label>IGST</label></div> <div class="col-sm-6 col-12 form-group"><label>'+igst+'</label></div> ';
     } 

     $('#business_totalamount1').empty();
     $('#business_totalamount1').append('<div class="col-sm-12 col-12"> <div class="row clearfixed">                                        <div class="col-sm-6 col-12 form-group"> <label> Gross Amount </label></div> <div class="col-sm-6 col-12 form-group"><label>'+total+'</label></div>'+gst+'<div class="col-sm-6 col-12 form-group"> <label> Total Amount </label></div> <div class="col-sm-6 col-12 form-group"><label>'+grandtoatal+'</label></div> </div></div>');
      $('#add_business_packages_total').val(total);
      $('#business_packages_total').val(total);
      $('#business_packages_state_id').val(state_id);
      
 }

$(document).ready(function(){

  $("#business_applypromocode").click(function(){
 
 var business_packages_promocode = $('#business_packages_promocode').val();
 var totalamount = $('#business_packages_total').val();
 var state_id = $('#business_packages_state_id').val();

    $.ajax({
    type: "POST",
    url:url+'Common/getAmountPromocodeforBusiness',
    data:{business_packages_promocode:business_packages_promocode},
    dataType: 'json',
    
  success:function(result){
      if(result.success===true)
      { 
 $('#business_totalamount1').hide();
 var discountamount=0 ;
if(result.data[0].discount_amount !='NULL' && result.data[0].discount_amount >0){
$( "#business_promcodeamount-msg" ).html("<div class='alert alert-success'>"+result.data[0].discount_amount+"Rs Discount to Using this Promocode </div>"); 

  discountamount=result.data[0].discount_amount;
  var discountamount= parseFloat(discountamount).toFixed(2);

}else if(result.data[0].discount_percentage != 'NULL'){
$("#business_promcodeamount-msg" ).html("<div class='alert alert-success'>"+result.data[0].discount_percentage+"% Discount to Using this Promocode </div>");   
        var percentage=result.data[0].discount_percentage; 
        discountamount =(totalamount/100) * percentage ;
var discountamount= parseFloat(discountamount).toFixed(2);
}

    $('#business_grandtotalamount').empty();
  var total=totalamount-discountamount;
			  if(state_id==32){
			        var cgst=Number(total*9/100);
			        var sgst=Number(total*9/100);

			        var cgst= parseFloat(cgst).toFixed(2);
			        var sgst= parseFloat(sgst).toFixed(2);
			        var grandtoatal= parseFloat(total) + parseFloat(cgst)+parseFloat(sgst);
			        var grandtoatal= parseFloat(grandtoatal).toFixed(2);
			        
			        var gst='<div class="col-sm-6 col-12"> <label> CGST </label></div> <div class="col-sm-6 col-12"><label>'+cgst+'</label></div> <div class="col-sm-6 col-12"> <label> SGST</label></div> <div class="col-sm-6 col-12"><label>'+sgst+'</label></div>';
			       
			     }else{
			       var igst=Number(total*18/100);
			       var igst= parseFloat(igst).toFixed(2);
			       var grandtoatal= parseFloat(total) + parseFloat(igst);
			       var grandtoatal= parseFloat(grandtoatal).toFixed(2);
			       var gst='<div class="col-sm-6 col-12"> <label>IGST</label></div> <div class="col-sm-6 col-12"><label>'+igst+'</label></div> ';
			      
			     } 
 
		  $('#business_grandtotalamount').append('<div class="col-sm-12 col-12"> <div class="row clearfixed">                                       <div class="col-sm-6 col-12"><label> Actual Price </label></div> <div class="col-sm-6 col-12"><label>'+totalamount+'</label></div>      <div class="col-sm-6 col-12"><label> Discount Amount </label></div> <div class="col-sm-6 col-12"><label>'+discountamount+'</label></div> <div class="col-sm-6 col-12"><label> Discount Price </label></div> <div class="col-sm-6 col-12"><label>'+total+'</label></div> '+gst+'<div class="col-sm-6 col-12 "> <label> Total Amount </label></div> <div class="col-sm-6 col-12"><label>'+grandtoatal+'</label></div>                                                                                                                                      </div></div>')
		  // $('#business_discount').empty();
		  // $('#business_discount').append('<div class="col-sm-12 col-12"> <div class="row clearfixed"><div class="col-sm-6 col-12"><label> Discount Amount </label></div> <div class="col-sm-6 col-12"><label>'+discountamount+'.00</label></div></div></div>')
		  $('#add_business_packages_discountamount').val(discountamount);
		  $('#add_business_packages_grandtotal').val(total);
		  $('#add_business_packages_promocode_id').val(result.data[0].id);
       
        }else if(result.success==false){
            $('#business_totalamount1').hide();  
            $('#business_grandtotalamount').empty();
            // $('#business_discount').empty();
             $('#business_promcodeamount-msg').hide().fadeIn('slow').delay(1000).fadeOut(2200);   
             $("#business_promcodeamount-msg" ).html("<div class='alert alert-danger'>"+result.message+"</div>"); 

             var total=totalamount;
			  if(state_id==32){
			        var cgst=Number(total*9/100);
			        var sgst=Number(total*9/100);
			         var cgst= parseFloat(cgst).toFixed(2);
			        var sgst= parseFloat(sgst).toFixed(2);
			        var grandtoatal= parseFloat(total) + parseFloat(cgst)+parseFloat(sgst);
			        var grandtoatal= parseFloat(grandtoatal).toFixed(2);
			          var gst='<div class="col-sm-6 col-12"> <label> CGST </label></div> <div class="col-sm-6 col-12"><label>'+cgst+'</label></div> <div class="col-sm-6 col-12 "> <label> SGST</label></div> <div class="col-sm-6 col-12"><label>'+sgst+'</label></div>';
			       
			     }else if(state_id!=32){
			       var igst=Number(total*18/100);
			       var igst= parseFloat(igst).toFixed(2);
			       var grandtoatal= parseFloat(total) + parseFloat(igst);
			       var grandtoatal= parseFloat(grandtoatal).toFixed(2);
			      var gst='<div class="col-sm-6 col-12"> <label>IGST</label></div> <div class="col-sm-6 col-12"><label>'+igst+'</label></div> '
			     } 
			 
				$('#business_grandtotalamount').append('<div class="col-sm-12 col-12"> <div class="row clearfixed"><div class="col-sm-6 col-12"><label> Actual Price </label></div> <div class="col-sm-6 col-12"><label>'+totalamount+'</label></div>'+gst+'<div class="col-sm-6 col-12 "> <label> Total Amount </label></div> <div class="col-sm-6 col-12"><label>'+grandtoatal+'</label></div></div></div>')
				$('#add_business_packages_grandtotal').val('');
				$('#add_business_packages_total').val(total);
				$('#business_packages_total').val(total);
      }

    },
 
 fail:function(result){
      
      alert('Information request failed: ' + textStatus, 'error');
    }


});
    });

// ==== business search starts == //

$("#search_business").validate({
     
     rules:{
        // search_business_cname :"required",
        // search_business_city :"required",
      
     }
 });

$("#searchbusiness").click(function() {
    if(!$("#search_business").valid())
   {
     return false;
   }
  
   var formData = new FormData($("#search_business")[0] );
     $.ajax({
      type:"POST",
    url:url+"Common/SearchBusinessList",
    dataType: 'json',
    data:formData,
    contentType: false, 
    cache: false,      
    processData:false,
beforeSend: function(){
    // Show image container
    $(".loader").show();
},
      success: function(result){
      
      if(result.success==true){
        BusinessViewList(result.data,result.role)
       }
      else if(result.success===false){
        alert('Information request failed:error, Please try Again....');
      }
    },
    
     complete:function(){
    // Hide image container
    $(".loader").hide();
}, 
    failure: function (result){

      alert('Information request failed: error, Please try Again....');
    } 

 });


});
// ==== business search ends == //


/* ====== keywords  details  start ===== */ 

viewBusinessKeywords();   
        function viewBusinessKeywords(){
            $.ajax({
                type  : 'GET',
                url   : url+"Common/getBusinessKeywordslist",
                async : true,
                dataType : 'json',
                success : function(result){
     if(result.success==true){
        businesskeywordsview(result.data);
      
              }        
                }
            });
        }

  function businesskeywordsview(keywordlist){
    
       var items = "";
       var edititems = "";
       var i;
       var n = keywordlist.length;

for(i=0;i<n;i++) {
   items+= '<div class="col-md-4 col-12 form-group"> <input type="radio"  value='+keywordlist[i].id+' id="add_business_businesskeyword" name="add_business_businesskeyword"  style="display: inline;"> <span class="form-label" for="add_business_businesskeyword"> '+keywordlist[i].category_name+' </span></div>'

       }

         $("#addkeywordsbusiness").html(items);
  
  }


// $("#searchbusinesskeywordscategory").click(function(){
  $( "#search_business_keyword" ).keyup(function() {

var search_business_keyword = $('#search_business_keyword').val();
 var items =" ";
   $.ajax({
       type:"POST",
       url:url+"Common/SearchKeywordsForBusinessList",
    dataType: 'json',
    data:{search_business_keyword:search_business_keyword},
    dataType: 'json',

 success: function(result){
      
      if(result.success===true){

          businesskeywordsview(result.data)
   }
  else if(result.success===false){
        $('#search_business_keywords-msg').hide().fadeIn('').delay(1000).fadeOut(2200);
        $( "#search_business_keywords-msg" ).html("<div class='alert alert-danger'>"+result.message+"</div>");
      }
    },
    
    failure: function (result){
      $('#search_business_keywords-msg').hide().fadeIn('slow').delay(1000).fadeOut(2200);
      $( "#search_business_keywords-msg" ).html("<div class='alert alert-danger'>Some thing went wrong try again ...</div>");      
    } 
         
      });

});

/* ======  keywords  details  end ===== */



/* ======  demo websites  details start ===== */
$("#searchbusinesswebcategory").click(function(){
  var search_website = $('#search_business_website').val();
  searchdemowebsitesByCategory(search_website);
});
/* ======  demo websites  details end ===== */


$(document).on('click', '.project_status_edit a', function(e){
 var id= $(this).attr("data-businessid");
 $.ajax({
    type: "GET",
    url:url+'DealClosedController/editProjectStatusByid/'+id,
    dataType: 'json',
  success:function(result){
      if(result.success===true)
      { 
       $('#project_change_status_form #project_change_status_id').val(id);
       $('#project_change_status_form #project_change_status').val(result.data[0].project_status_id).prop("selected", true);
    
       }else{
            alert('request failed', 'error');
      }
    },
 fail:function(result){
      
      alert('Information request failed: ' + textStatus, 'error');
    }
  });

});


$("#projectupdatestatus").click(function(){
    if(!$("#project_change_status_form").valid())
   {
     return false;
   }
  var formData = new FormData($("#project_change_status_form")[0] );
   $.ajax({
       type:"POST",
       url:url+"DealClosedController/ProjectupdateStatusByid",
    dataType: 'json',
    data:formData,
    contentType: false, 
    cache: false,      
    processData:false,
 success: function(result){
      if(result.success===true){
        $('#citymapping-editmsg').hide().fadeIn('slow').delay(1000).fadeOut(2200);    
          $("#citymapping-editmsg" ).html("<div class='alert alert-success'>"+result.message+"</div>");
           $("#change_status_form")[0].reset();
            setTimeout(function(){
               $('#projectEditstatusModal').modal('hide');
                }, 5000);

       window.setTimeout(function(){location.reload()},3000);

            }else if(result.success===false){
        $('#citymapping-editmsg').hide().fadeIn('').delay(1000).fadeOut(2200);
        $( "#citymapping-editmsg" ).html("<div class='alert alert-danger'>"+result.message+"</div>");
      }
    },
    
    failure: function (result){

      $('#citymapping-editmsg').hide().fadeIn('slow').delay(1000).fadeOut(2200);
      $( "#citymapping-editmsg" ).html("<div class='alert alert-danger'>Some thing went wrong try again ...</div>");      
    } 
         
      });


});



$("#generated_opt").click(function() {
var add_business_mobileno = $("#add_business_mobileno").val();
var add_newbusiness_payment_mode =$("input:radio[name=add_newbusiness_payment_mode]:checked").val(); 
var add_business_packages_total = $("#add_business_packages_total").val();
var add_business_packages_grandtotal = $("#add_business_packages_grandtotal").val();
   $.ajax({
    type:"POST",
    url:url+"Welcome/OtpSendToMobile",
    dataType: 'json',
    data:{add_business_mobileno:add_business_mobileno,add_newbusiness_payment_mode:add_newbusiness_payment_mode,add_business_packages_total:add_business_packages_total,add_business_packages_grandtotal:add_business_packages_grandtotal},
    dataType: 'json',

 success: function(result){
      
      if(result.success==true){
          alert(result.message);
           $('#otpverficationmodal').modal('show');
        }
  else if(result.success==false){
        alert(result.message);
      }
    },
    
    failure: function (result){
      alert("Some thing went wrong try again ...");
    } 
         
      });

});

// }


$("#otp_verification").click(function() {
var mobileOtp = $("#mobileOtp").val();
 var items =" ";
   $.ajax({
       type:"POST",
       url:url+"Welcome/OtpVerficationToMobile",
    dataType: 'json',
    data:{mobileOtp:mobileOtp},
    dataType: 'json',

 success: function(result){
      
      if(result.success==true){
        
        $('#add_business_otp').val(mobileOtp);
        $('#otpverficationmodal').modal('hide');    
        alert(result.message);
   }
  else if(result.success===false){
       alert(result.message);
      }
    },
    
    failure: function (result){
     alert("Some thing went wrong try again ...");
    } 
         
      });

});



/* ====== add  keywords  details  start ===== */
$("#add_new_business_keywords").validate({
     
     rules:{
        add_new_business_keywords_name :"required"
     }
 });

$("#addnewbusinesskeywords").click(function() {
  
    if(!$("#add_new_business_keywords").valid())
   {
     return false;
   }
  
   var formData = new FormData($("#add_new_business_keywords")[0] );
     $.ajax({
      type:"POST",
    url:url+"Common/saveNewKeywords",
    dataType: 'json',
    data:formData,
    contentType: false, 
    cache: false,      
    processData:false,
      success: function(result){
      if(result.success==true){
        $('#businesskeywordsnew-addmsg').hide().fadeIn('slow').delay(1000).fadeOut(2200);    
          $( "#businesskeywordsnew-addmsg" ).html("<div class='alert alert-success'>"+result.message+"</div>");
        $('#add_new_business_keywords')[0].reset();
        setTimeout(function(){
               $('#AddNewBusinesskeywordsModal').modal("hide");
                    }, 5000); 
       }else{
        $('#businesskeywordsnew-addmsg').hide().fadeIn('').delay(1000).fadeOut(2200);
        $( "#businesskeywordsnew-addmsg" ).html("<div class='alert alert-danger'>"+result.message+"</div>");
      }
    },
    
    failure: function (result){
      $('#businesskeywordsnew-addmsg').hide().fadeIn('slow').delay(1000).fadeOut(2200);
      $( "#businesskeywordsnew-addmsg" ).html("<div class='alert alert-danger'>Some thing went wrong try again ...</div>");      
    } 
  });

});
/* ====== add  keywords  details  end ===== */

/* ==== payment pending start  ===*/
 $(document).on('click', '.business_payment_pending a', function(e){
 var id= $(this).attr("data-selectedid");
 var name=$(this).attr("data-selectedname");
 $(".lisofbusiness-class").hide();
$.ajax({
    type: "GET",
    url:url+'Common/BusinessPaymentPending/'+id,
    dataType: 'json',
  success:function(result){
      if(result.success===true)
      { 
        $(".paymentpending-class").show();
        $('#add_business_paymentpending #business_paymentpending_package_id').val(result.data[0].business_package_id);
        $('#add_business_paymentpending #business_paymentpending_business_id').val(result.data[0].business_id);

        $('#add_business_paymentpending #add_paymentpending_status').val(result.data[0].business_status_id).prop('selected', true);

        $('#business_paymentpending_company_name').html(result.data[0].company_name);
        $('#business_paymentpending_person_name').html(result.data[0].person_name);
        $('#business_paymentpending_designation').html(result.data[0].person_designation);
        $('#business_paymentpending_mobileno').html(result.data[0].mobile_no);
        $('#business_paymentpending_email').html(result.data[0].email);
        $('#business_paymentpending_address').html(result.data[0].address);
        $('#business_paymentpending_subtotal').html(result.data[0]. total_amount);
        $('#business_paymentpending_discount').html(result.data[0].discount_amount);
        $('#business_paymentpending_total').html(result.data[0].grand_total_amount);
       if(result.data[0].cgst_amount!=null && result.data[0].sgst_amount!=null && result.data[0].cgst_amount!=0 && result.data[0].sgst_amount!=0){
            var gst=Number(Number(result.data[0].cgst_amount)+Number(result.data[0].sgst_amount));
         }else if(result.data[0].igst_amount!=null ){
           var gst=Number(result.data[0].igst_amount);
         }
        $("#business_paymentpending_gst").html(gst);
        $("#business_paymentpending_gstgrandtotal").html(result.data[0].gstgrand_total_amount);
        $("#receipt_payment_methode").html(result.data[0].paymenttype_name);
        $("#receipt_order_id").html(result.data[0].order_id);  
	        for(var i=0; i<result.campaigndata.length;i++){
	       $("#business_paymentpending_packages_table > tbody").append('<tr><td>'+result.campaigndata[i][0].campaign_name+'</td><td>'+result.campaigndata[i][0].campaign_amount+'</td></tr>');
	               }             
    
		    for(var j=0; j<result.packagesdata.length;j++){
		       $("#business_paymentpending_packages_table > tbody").append('<tr><td>'+result.packagesdata[j][0].package_name+'</td><td>'+result.packagesdata[j][0].package_amount+'</td></tr>');
		    } 

        var transctiontotal=0;
		    for(var j=0; j<result.paymenttransction.length;j++){
		       $("#business_paymentpending_transctiondetails > tbody").append('<tr><td>'+result.paymenttransction[j].order_id+'</td><td>'+result.paymenttransction[j].transaction_amount+'</td><td>'+result.paymenttransction[j].paymenttype_name+'</td><td>'+result.paymenttransction[j].transaction_status+'</td></tr>');
		       if(result.paymenttransction[j].transaction_status=="SUCCESS"){ 
		         var amount=result.paymenttransction[j].transaction_amount;
		            transctiontotal += parseFloat(amount);
		          }
             } 

      $("#business_paymentpending_transction_gstgrandtotal").html(result.data[0].gstgrand_total_amount);
      var transctiontotal= parseFloat(transctiontotal).toFixed(2);
      $("#business_paymentpending_transction_grandtotal").html(transctiontotal);
        var pendingtotal= parseFloat(result.data[0].gstgrand_total_amount)-parseFloat(transctiontotal);
        var pendingtotal= parseFloat(pendingtotal).toFixed(2);
        $("#business_paymentpending_transction_pendingtotal").html(pendingtotal);
        $("#business_paymentpending_transction_pendingtotal_showingpending").html(pendingtotal);
        $("#business_paymentpending_pendingtotal").val(pendingtotal);
       
      }else{
            alert('request failed', 'error');
      }

    },
   
 
 fail:function(result){
      
      alert('Information request failed: ' + textStatus, 'error');
    }

});


});




var paymentpendingaddform = $("#add_business_paymentpending");
paymentpendingaddform.validate({
    errorPlacement: function errorPlacement(error, element) { element.before(error); },
    rules: {
      add_paymentpending_status :"required"
     
    }
});

paymentpendingaddform.children("div").steps({
    headerTag: "h3",
    bodyTag: "section",
    transitionEffect: "slideLeft",
    onStepChanging: function (event, currentIndex, newIndex)
    {
        paymentpendingaddform.validate().settings.ignore = ":disabled,:hidden";
        return paymentpendingaddform.valid();
    },
    onFinishing: function (event, currentIndex)
    {
        paymentpendingaddform.validate().settings.ignore = ":disabled";
        return paymentpendingaddform.valid();
    },
    onFinished: function (event, currentIndex)
    {
         
    var formData = new FormData($("#add_business_paymentpending")[0] );
     $.ajax({
      type:"POST",
     url:url+"Common/savePaymentpendingData",
    dataType: 'json',
    data:formData,
    contentType: false, 
    cache: false,      
    processData:false,
beforeSend: function(){
    // Show image container
    $(".loader").show();
},

      success: function(result){
      
      if(result.success==true){

        $('#paymentpendingdata-addmsg').hide().fadeIn('slow').delay(1000).fadeOut(2200);   
        $( "#paymentpendingdata-addmsg" ).html("<div class='alert alert-success'>"+result.message+"</div>");
        $('#add_business_paymentpending')[0].reset(); 
        window.setTimeout(function(){location.reload()},3000);
      
      }
      else{
        $('#paymentpendingdata-addmsg').hide().fadeIn('').delay(1000).fadeOut(2200);
        $( "#paymentpendingdata-addmsg" ).html("<div class='alert alert-danger'>"+result.message+"</div>");
      }
    },
     complete:function(){
    // Hide image container
    $(".loader").hide();
}, 
    
    failure: function (result){

      $('#paymentpendingdata-addmsg').hide().fadeIn('slow').delay(1000).fadeOut(2200);
      $( "#paymentpendingdata-addmsg" ).html("<div class='alert alert-danger'>Some thing went wrong try again ...</div>");     
    } 
         
      });

    }
});

/* ==== payment pending ends  ===*/ 

/* ==== Receipt ends  ===*/

$(document).on('click', '.business_receipt a', function(e){
 var id= $(this).attr("data-selectedid");
 var name=$(this).attr("data-selectedname");
 $(".lisofbusiness-class").hide();
 $(".listofreceipt-class").show();
$.ajax({
    type: "GET",
    url:url+'Common/BusinessReceiptList/'+id,
    dataType: 'json',
  success:function(result){
      if(result.success===true)
      { 
        
        if ( $.fn.DataTable.isDataTable('#listofreceipttable')) {
         $('#listofreceipttable').DataTable().destroy();
         }  
         $('#listofreceipttable tbody').empty();

         var data=result.data; 
         var table = $('#listofreceipttable').DataTable({
        
         paging: true,
         searching: true,
         columns: [
      {data: 'id',title: 'Sno'},
      {data: 'created_on',title:'Date'},
      {data: 'order_id',title:'Order Id'},
      {data: 'paymenttype_name',title:'Payment Type'}, 
      {data: 'transaction_amount',title:'Paid Amount'}, 
      {data: 'transaction_status',title:'Transction Status'},
      {data: null,
          'title' : 'Action',
          "sClass" : "center",
          mRender: function (data, type, row) {
                         return '<button class="btn btn-info btn-sm business_receipt_byid"  id="business_receipt_byid" title="Receipt" ><a data-selectedid="'+data.id+'" data-selectedname="' +data.company_name+ '" style="color:#FFFFFF;"><i class="mdi mdi-file-document"></i></a></button>&nbsp;'
        } }
     ]
   
 });

table.rows.add(data).draw();

       
      }else{
            alert('request failed', 'error');
      }
    },
 fail:function(result){
      
      alert('Information request failed: ' + textStatus, 'error');
    }

});


});



$(document).on('click', '.business_receipt_byid a', function(e){
 var id= $(this).attr("data-selectedid");
 var name=$(this).attr("data-selectedname");
 $(".listofreceipt-class").hide();
$.ajax({
    type: "GET",
    url:url+'Common/BusinessReceipt/'+id,
    dataType: 'json',
  success:function(result){
      if(result.success===true)
      { 
        $(".receipt-class").show();
        $('#export_receipt #business_receipt_selectedid').val(result.data[0].id);
        // alert(result.data[0].id);
        $('#receipt_date').html(result.data[0].created_on);
        $('#receipt_number').html(result.data[0].id);
        $('#receipt_company_name').html(result.data[0].company_name);
        $('#receipt_company_address').html(result.data[0].address);
        $('#receipt_company_city').html(result.data[0].cityname);
        $('#receipt_comapy_state').html(result.data[0].state_name); 
        $('#receipt_person_designation').html(result.data[0].person_designation); 
        $('#receipt_person_name').html(result.data[0].person_name); 
        $('#receipt_email').html(result.data[0].email); 

        $('#receipt_mobile_no').html(result.data[0].mobile_no);
        $('#receipt_total_payment').html(result.data[0].grand_total_amount);
        $('#receipt_bank_name').html(result.data[0].bank_name);
        
        // $('#receipt_pay_date').html(result.data[0].created_on);
       //  $("#receipt_sub_total").html(result.data[0].total_amount);
       //  $("#receipt_discount_amount").html(result.data[0].discount_amount);
       //  $("#receipt_total_amount").html(result.data[0].grand_total_amount);
       // if(result.data[0].cgst_amount!=null && result.data[0].sgst_amount!=null){
       //  var gst=Number(Number(result.data[0].cgst_amount)+Number(result.data[0].sgst_amount));
       // }else if(result.data[0].igst_amount!=null ){
       //   var gst=Number(result.data[0].igst_amount);
       // }
       //  $("#receipt_gst").html(gst);
       //  $("#receipt_grand_total").html(result.data[0].gstgrand_total_amount);

           // alert(result.data[0].transaction_amount);
        $("#receipt_transaction_amount").html(result.data[0].transaction_amount);
        $("#receipt_transaction_status").html(result.data[0].transaction_status);
        $("#receipt_payment_methode").html(result.data[0].paymenttype_name);
        $("#receipt_order_id").html(result.data[0].order_id);
        $("#receipt_marketing_name").html(result.data[0].name);
        
       
      }else{
            alert('request failed', 'error');
      }
    },
 fail:function(result){
      
      alert('Information request failed: ' + textStatus, 'error');
    }

});

});

/* ==== Receipt ends  ===*/

    }); // document ready