var url=base_url.baseurl;

$(document).ready(function(){

$(function(){
		 var items="";
		 $.getJSON(url+"market-lead/TodayAllAppointmentsController/TodayAppointForMarketingLead", function(todayallappointmentsList){
		  $.each(todayallappointmentsList,function(index,itemlist)
		 {

		 if ( $.fn.DataTable.isDataTable('#todayallapptable')) {
				 $('#todayallapptable').DataTable().destroy();
				 }	
				 $('#todayallapptable tbody').empty();

				 var data=itemlist; 
				 var table = $('#todayallapptable').DataTable({
				
				 paging: true,
				 searching: true,
				 columns: [
		  {data: 'id',title: 'S No.'},
      {data: 'company_name',title:'Company Name'},
      {data: 'person_name',title:'Contact Person Name'},
      {data: 'mobile_no',title:'Contact Person Phone'},
      {data: 'tele_marketing_name',title:'Assigned By'}, 
      {data: 'marketing_name',title:'Assigned To'},
      {data: 'appointment_time',title:'Appointment Time'},
      {data: 'message',title:'Message'},
      {data: 'status_value',title:'Status'},
      {data: null,
          'title' : 'Action',
          "sClass" : "center",
          mRender: function (data, type, row) {
    return '<button class="btn btn-info btn-sm mt-2 market_lead_status_edit" data-toggle="modal" id="market_lead_status_edit" data-target="#market_lead_EditstatusModal" title="Edi Business Status"><a data-businessid="'+data.id+'" data-businessname="' +data.company_name+ '" style="color:#ffffff"> <i class="mdi mdi-pencil-box"></i> </a></button> &nbsp;<button class="btn btn-info btn-sm mt-2 market_lead_selectedpackages" title="Select Package"><a data-businessid="'+data.id+'" data-businessname="' +data.company_name+ '"style="color:#ffffff" data-businessstate_id="'+data.state_id+'" > <i class="mdi mdi-package-variant" data-name="mdi-package-variant"></i> </a></button>&nbsp;<button class="btn btn-info btn-sm mt-2  marketeditbusiness" id="businessdata_edit" title="Edit Business Details" style="color:#0066ff"><a data-businessid="'+data.id+'" data-businessname="' +data.company_name+ '"  style="color:#ffffff"> <i class="mdi mdi-grease-pencil"></i> </a></button>&nbsp; <button class="btn btn-primary btn-sm mt-2 marketlead_listofbusiness" title="Payment History"><a data-businessid="'+data.id+'" data-businessname="' +data.company_name+ '" style="color:#ffffff" > <i class="mdi mdi-wallet" data-name="mdi-package-variant"></i> </a></button>'
              } }
        ],
			 });
table.rows.add(data).draw();
		  });	
   });	
 });

$('[data-toggle="modal"]').tooltip();

$(document).on('click', '.market_lead_status_edit a', function(e){
 var id= $(this).attr("data-businessid");
 $.ajax({
    type: "GET",
    url:url+'market-lead/TodayAllAppointmentsController/MarketLeadeditStatusByid/'+id,
    dataType: 'json',
  success:function(result){
      if(result.success===true)
      { 
       $('#market_lead_change_status_form #market_lead_change_status_id').val(id);
       $('#market_lead_change_status_form #market_lead_change_status').val(result.data[0].business_status_id).prop("selected", true);
       }else{
            alert('request failed', 'error');
      }

    },
   
 fail:function(result){
      
      alert('Information request failed: ' + textStatus, 'error');
    }
});

});


 $("#market_lead_updatestatus").click(function(){
    if(!$("#market_lead_change_status_form").valid())
   {
     return false;
   }
  var formData = new FormData($("#market_lead_change_status_form")[0] );
   $.ajax({
       type:"POST",
       url:url+"market-lead/TodayAllAppointmentsController/MarketLeadupdateStatusByid",
    dataType: 'json',
    data:formData,
    contentType: false, 
    cache: false,      
    processData:false,

 success: function(result){
      
      if(result.success===true){
      
        $('#citymapping-editmsg').hide().fadeIn('slow').delay(1000).fadeOut(2200);    
          $("#citymapping-editmsg" ).html("<div class='alert alert-success'>"+result.message+"</div>");

           $("#market_lead_change_status_form")[0].reset();
            setTimeout(function(){
               $('#market_lead_EditstatusModal').modal('hide');
                }, 5000); 

       BusinessviewListData();

   }
  else if(result.success===false){
        $('#citymapping-editmsg').hide().fadeIn('').delay(1000).fadeOut(2200);
        $( "#citymapping-editmsg" ).html("<div class='alert alert-danger'>"+result.message+"</div>");
      }
    },
    
    failure: function (result){

      $('#citymapping-editmsg').hide().fadeIn('slow').delay(1000).fadeOut(2200);
      $( "#citymapping-editmsg" ).html("<div class='alert alert-danger'>Some thing went wrong try again ...</div>");      
    } 
         
      });


});



$(document).on('click', '.market_lead_selectedpackages a', function(e){

 var id= $(this).attr("data-businessid");
 var name=$(this).attr("data-businessname");
 var state_id=$(this).attr("data-businessstate_id");
$("#market_lead_add_packages_companyname_state_id").val(state_id);
$("#market_lead_add_packages_companyname").val(id);

$("#market_lead_cname").html(name);
$(".market_lead_todayAppointmentList_class").hide();
$(".market_lead_addpackages-class").show();


   });
 


 viewDemowebsitesForPackages();   
        function viewDemowebsitesForPackages(){
            $.ajax({
                type  : 'GET',
                url   : url+"Common/SearchWebsitesForBusinessList",
                async : true,
                dataType : 'json',
                success : function(result){
     if(result.success==true){
        viewDemowebsitesForPackagesList(result.data);
      
              }        
                }
            });
        }

  function viewDemowebsitesForPackagesList(demowebsites){
       var items = "";
       var edititems = "";
       var i;
       var n = demowebsites.length;

    for(var i=0; i<n; i++){
        items+='<div class="col-md-4 col-6 form-group"><div class="demoweb card"><img src="'+url+demowebsites[i].web_photo+'" alt="web image" class="image"><div class="container"><h6 class="p-2">'+demowebsites[i].web_name+'</h6></div><div class="overlay"><div class="text"><a  href="'+demowebsites[i].web_url+'" class="btn btn-info btn-rounded btn-fw mb-3" target="_blank">Live Demo</a><a  href="'+demowebsites[i].web_url+'" class="btn btn-light btn-rounded btn-fw" target="_blank">Preview</a></div></div></div></div>';
     }    

        // $("#demowebsitesbusiness").html(items);
        $("#demowebsitespackages").html(items);;
  
  }
function searchdemowebsitesByCategoryForPackages(search_website){
  var search_business_website = search_website;
 var items =" ";
   $.ajax({
       type:"POST",
       url:url+"Common/SearchWebsitesForBusinessList",
    dataType: 'json',
    data:{search_business_website:search_business_website},
    dataType: 'json',
 success: function(result){
      if(result.success==true){
        viewDemowebsitesForPackagesList(result.data);  
      }
  else if(result.success==false){
        $('#search_packages_website-msg').hide().fadeIn('').delay(1000).fadeOut(2200);
        $( "#search_packages_website-msg" ).html("<div class='alert alert-danger'>"+result.message+"</div>");
      }
    },
    
    failure: function (result){
      $('#search_packages_website-msg').hide().fadeIn('slow').delay(1000).fadeOut(2200);
      $( "#search_packages_website-msg" ).html("<div class='alert alert-danger'>Some thing went wrong try again ...</div>");      
    } 
         
      });
}


var market_lead_packagesform = $("#market_lead_add_packagesdata");
market_lead_packagesform.validate({
    errorPlacement: function errorPlacement(error, element) { element.before(error); },
    rules: {
      // market_lead_add_packages_companyname :"required",
      // add_business_campaign :"required",
      add_package_condition:"required",
      market_lead_add_packages_debitcardno:{number:true,minlength:5, maxlength:18},
      market_lead_add_packages_creditcardno:{number:true,minlength:5, maxlength:18},
      market_lead_add_packages_chequeno:{number:true,minlength:4, maxlength:12},
      market_lead_add_packages_cchequeno:{number:true,minlength:4, maxlength:12,equalTo:"#market_lead_add_packages_chequeno"},
      market_lead_add_packages_cheque_micr:{number:true},
      market_lead_add_packages_accountno:{number:true,minlength:5, maxlength:20},
      market_lead_add_packages_caccountno: {number:true,minlength:5, maxlength:20,equalTo: "#market_lead_add_packages_accountno"},
      market_lead_add_packages_cacholdername: { equalTo: "#market_lead_add_packages_acholdername"},
      market_lead_add_packages_phonepay:{number:true,minlength:10, maxlength:12},
      market_lead_add_packages_amazonpay:{number:true,minlength:10, maxlength:12},
      market_lead_add_packages_googlepay:{number:true,minlength:10, maxlength:12},
    
    }
});

market_lead_packagesform.children("div").steps({
    headerTag: "h3",
    bodyTag: "section",
    transitionEffect: "slideLeft",
    onStepChanging: function (event, currentIndex, newIndex)
    {   
      var search_website = $("#market_lead_add_packages_businesskeyword:checked").val();
       searchdemowebsitesByCategoryForPackages(search_website);
         var paymentmodeid = $("#add_business_payment_mode:checked").val();
         var add_business_creditcard_expireddate=$("#add_newbusiness_payment_mode").val();
         var add_business_creditcardno=$("#add_business_creditcardno").val();
         
         if(paymentmodeid==3 && (!add_business_creditcard_expireddate || add_business_creditcard_expireddate.length<=0) && (!add_business_creditcardno ||  add_business_creditcardno.length<=0)){
            alert("Please fill all Credit Card Mode options!!!");
            return false;
         }
         
         var add_business_chequeaccountno=$("#market_lead_add_packages_chequeaccountno").val();
         var add_business_chequeno=$("#market_lead_add_packages_chequeno").val();
         var add_business_cchequeno=$("#market_lead_add_packages_cchequeno").val();
         var add_business_cheque_micr=$("#market_lead_add_packages_cheque_micr").val();
         var add_business_cheque_photo=$("#market_lead_add_packages_cheque_photo").val();
         var add_business_chequeissuedate=$("#market_lead_add_packages_chequeissuedate").val();
         
         if(paymentmodeid==6 && (!add_business_chequeaccountno || add_business_chequeaccountno.length<=0) && (!add_business_chequeno ||  add_business_chequeno.length<=0) && (!add_business_cchequeno || add_business_cchequeno.length<=0) && (!add_business_cheque_micr || add_business_cheque_micr.length<=0) && (!add_business_cheque_photo || add_business_cheque_photo.length<=0) && (!add_business_chequeissuedate || add_business_chequeissuedate.length<=0)){
            alert("Please fill all Cheque Mode options!!!");
            return false;
         }
         
         var add_business_cashamount=$("#market_lead_add_packages_cashamount").val();
         var add_business_cashdate=$("#market_lead_add_packages_cashdate").val();
         var add_business_personame=$("#market_lead_add_packages_personame").val();
         var add_business_placename=$("#market_lead_add_packages_placename").val();
         
         
         if(paymentmodeid==1 && (!add_business_cashamount || add_business_cashamount.length<=0) && (!add_business_cashdate ||  add_business_cashdate.length<=0) && (!add_business_personame ||  add_business_personame.length<=0) && (!add_business_placename ||  add_business_placename.length<=0)){
            alert("Please fill all Cash Mode options!!!");
            return false;
         }
         
         if (currentIndex < newIndex)
        {
            // To remove error styles
            $(".body:eq(" + newIndex + ") label.error", market_lead_packagesform).remove();
            $(".body:eq(" + newIndex + ") .error", market_lead_packagesform).removeClass("error");
        }
        //alert(businessform.valid());
        var result = $('ul[aria-label=Pagination]').children().find('a');
        $(result).each(function ()  { 
           if($(this).text() == 'Finish') {
               $(this).attr('disabled', true);
               $(this).css('background', 'green');
               
           }
           });
        
        //alert(currentIndex);
        
        market_lead_packagesform.validate().settings.ignore = ":disabled,:hidden";
        return market_lead_packagesform.valid();
     
    },
    onStepChanged: function (event, currentIndex)
    {    
         var total=0;
         var packagetotal=0;
         var campaigntotal=0;
     $('#totalamount1').show();  
     // $('#grandtotalamount').hide(); 
      $('#campaignlist1').empty();
        var n = $("#add_business_campaign:checked").length;
        if (n > 0){
            $("#add_business_campaign:checked").each(function(){
                //var campaign_id= $(this).val();
                var campainname=$(this).attr("data-cname");
                var campaignamount=$(this).attr("data-camount");
                campaigntotal += Number(campaignamount);

        $('#campaignlist1').append('<div class="col-sm-6 col-6 form-group" id="pakagesname"><label>'+campainname+'</label></div> <div class="col-sm-6 col-6 form-group" id="pakagesname"><label>'+campaignamount+'</label></div>');   
  
            });

        }

        $('#packagelist1').empty();
        var n = $("#add_business_package:checked").length;
        if (n > 0){
            $("#add_business_package:checked").each(function(){
                //var campaign_id= $(this).val();
                var packagename=$(this).attr("data-pname");
                var packageamount=$(this).attr("data-pamount");
               packagetotal += Number(packageamount); 
        $('#packagelist1').append('<div class="col-sm-6 col-6 form-group" id="pakagesname"><label>'+packagename+'</label></div> <div class="col-sm-6 col-6 form-group" id="pakagesname"><label>'+packageamount+'</label></div>');   
  
            });
        }
       
      var total=campaigntotal+packagetotal;
      var total= parseFloat(total).toFixed(2);
     var state_id = $('#market_lead_add_packages_companyname_state_id').val();
     if(state_id==32){
        var cgst=Number(total*9/100);
        var sgst=Number(total*9/100);

        var cgst= parseFloat(cgst).toFixed(2);
        var sgst= parseFloat(sgst).toFixed(2);
        var grandtoatal= parseFloat(total) + parseFloat(cgst)+parseFloat(sgst);
        var grandtoatal= parseFloat(grandtoatal).toFixed(2);

        var gst='<div class="col-sm-6 col-12 form-group"> <label> CGST </label></div> <div class="col-sm-6 col-12 form-group"><label>'+cgst+'</label></div> <div class="col-sm-6 col-12 form-group"> <label> SGST</label></div> <div class="col-sm-6 col-12 form-group"><label>'+sgst+'</label></div>';

       
     }else if(state_id!=32){
       var igst=Number(total*18/100);
       var igst= parseFloat(igst).toFixed(2);
       var grandtoatal= parseFloat(total) + parseFloat(igst);
       var grandtoatal= parseFloat(grandtoatal).toFixed(2);
      gst='<div class="col-sm-6 col-12 form-group"> <label>IGST</label></div> <div class="col-sm-6 col-12 form-group"><label>'+igst+'</label></div> ';
     } 
     // alert(grandtoatal);
     $('#totalamount1').empty();
     $('#totalamount1').append('<div class="col-sm-12 col-12"> <div class="row clearfixed"> <div class="col-sm-6 col-12 form-group"> <label> Gross Amount </label></div> <div class="col-sm-6 col-12 form-group"><label>'+total+'</label></div>'+gst+'<div class="col-sm-6 col-12 form-group"> <label> Total Amount </label></div> <div class="col-sm-6 col-12 form-group"><label>'+grandtoatal+'</label></div>           </div></div>')
      
      $('#market_lead_add_packages_total').val(total);
      

    },
    onFinishing: function (event, currentIndex)
    {  
        market_lead_packagesform.validate().settings.ignore = ":disabled";
        return market_lead_packagesform.valid();
       
    },
    onFinished: function (event, currentIndex)
    {
  
    var business_id=$('#market_lead_add_packages_companyname').val();   
  
    var formData = new FormData($("#market_lead_add_packagesdata")[0] );
     $.ajax({
    type:"POST",
    url:url+"market-lead/TodayAllAppointmentsController/savePackagesData",
    dataType: 'json',
    data:formData,
    contentType: false, 
    cache: false,      
    processData:false,
 beforeSend: function(){
    // Show image container
    $(".loader").show();
},
      success: function(result){
      
      if(result.success==true){

        $('#packagesdata-addmsg').hide().fadeIn('slow').delay(1000).fadeOut(2200);   
        $( "#packagesdata-addmsg" ).html("<div class='alert alert-success'>"+result.message+"</div>");
        $('#market_lead_add_packagesdata')[0].reset();
        
         // window.setTimeout(function(){location.reload()},3000)

         }
      else{
        $('#packagesdata-addmsg').hide().fadeIn('').delay(1000).fadeOut(2200);
        $( "#packagesdata-addmsg" ).html("<div class='alert alert-danger'>"+result.message+"</div>");
      }
    },
   complete:function(){
    // Hide image container
    $(".loader").hide();
},    
    failure: function (result){

      $('#packagesdata-addmsg').hide().fadeIn('slow').delay(1000).fadeOut(2200);
      $( "#packagesdata-addmsg" ).html("<div class='alert alert-danger'>Some thing went wrong try again ...</div>");     
    } 
         
      });

    }
});



$(document).ready(function(){

 $("#applypromocode").click(function(){
 
 var market_lead_add_packages_promocode = $('#market_lead_add_packages_promocode').val();
 var totalamount = $('#market_lead_add_packages_total').val();
 var market_lead_add_packages_companyname = $('#market_lead_add_packages_companyname').val();
 var state_id = $('#market_lead_add_packages_companyname_state_id').val();
 //var totalamount = $(this).attr("data-total");
 //alert(totalamount);
//alert(market_lead_add_packages_promocode);
    $.ajax({
    type: "POST",
    url:url+'market-lead/TodayAllAppointmentsController/getAmountPromocode',
    data:{market_lead_add_packages_promocode:market_lead_add_packages_promocode,market_lead_add_packages_companyname:market_lead_add_packages_companyname},
    dataType: 'json',
  beforeSend: function(){
    // Show image container
    $(".loader").show();
},  
  success:function(result){
      if(result.success===true)
      { 

 var discountamount=0 ;
 
if(result.data[0].discount_amount !='NULL' && result.data[0].discount_amount >0){
$( "#promcodeamount-msg" ).html("<div class='alert alert-success'>"+result.data[0].discount_amount+"Rs Discount to Using this Promocode </div>"); 

  discountamount=result.data[0].discount_amount;
  var discountamount= parseFloat(discountamount).toFixed(2);

}else if(result.data[0].discount_percentage != 'NULL' && result.data[0].discount_percentage != ' '){
$("#promcodeamount-msg" ).html("<div class='alert alert-success'>"+result.data[0].discount_percentage+"% Discount to Using this Promocode </div>");   
        var percentage=result.data[0].discount_percentage; 
        discountamount =(totalamount/100) * percentage ; 
        var discountamount= parseFloat(discountamount).toFixed(2);
       

}

$('#totalamount1').hide();  
    $('#grandtotalamount').empty();
   var total=totalamount-discountamount;
   var total= parseFloat(total).toFixed(2);
    if(state_id==32){
        var cgst=Number(total*9/100);
        var sgst=Number(total*9/100);

        var cgst= parseFloat(cgst).toFixed(2);
        var sgst= parseFloat(sgst).toFixed(2);
        var grandtoatal= parseFloat(total) + parseFloat(cgst)+parseFloat(sgst);
        var grandtoatal= parseFloat(grandtoatal).toFixed(2);

        var gst='<div class="col-sm-6 col-12"> <label> CGST </label></div> <div class="col-sm-6 col-12"><label>'+cgst+'</label></div> <div class="col-sm-6 col-12"> <label> SGST</label></div> <div class="col-sm-6 col-12"><label>'+sgst+'</label></div>';
       
     }else{
       var igst=Number(total*18/100);
       var igst= parseFloat(igst).toFixed(2);
       var grandtoatal= parseFloat(total) + parseFloat(igst);
       var grandtoatal= parseFloat(grandtoatal).toFixed(2);
       var gst='<div class="col-sm-6 col-12"> <label>IGST</label></div> <div class="col-sm-6 col-12"><label>'+igst+'</label></div> ';
      
     } 

      $('#grandtotalamount').append('<div class="col-sm-12 col-12"> <div class="row clearfixed">                                            <div class="col-sm-6 col-12"><label> Actual Price </label></div> <div class="col-sm-6 col-12"><label>'+totalamount+'</label></div>      <div class="col-sm-6 col-12"><label> Discount Amount </label></div> <div class="col-sm-6 col-12"><label>'+discountamount+'</label></div> <div class="col-sm-6 col-12"><label> Discount Price </label></div> <div class="col-sm-6 col-12"><label>'+total+'</label></div> '+gst+'<div class="col-sm-6 col-12 "> <label> Total Amount </label></div> <div class="col-sm-6 col-12"><label>'+grandtoatal+'</label></div>  </div></div>')

 // $('#discount').empty();
 //      $('#discount').append('<div class="col-sm-12 col-12"> <div class="row clearfixed"><div class="col-sm-6 col-12"><label> Discount Amount </label></div> <div class="col-sm-6 col-12"><label>'+discountamount+'</label></div></div></div>')
  $('#market_lead_add_packages_discountamount').val(discountamount);
  $('#market_lead_add_packages_grandtotal').val(grandtoatal);
  

  $('#market_lead_add_packages_promocode_id').val(result.data[0].id);

      }else if(result.success==false){
        
        $('#totalamount1').hide();  

            $('#grandtotalamount').empty();
            $('#discount').empty();
             $('#promcodeamount-msg').hide().fadeIn('slow').delay(1000).fadeOut(2200);   
             $("#promcodeamount-msg" ).html("<div class='alert alert-danger'>"+result.message+"</div>"); 

                  var total=totalamount;
  if(state_id==32){
        var cgst=Number(total*9/100);
        var sgst=Number(total*9/100);
        var cgst= parseFloat(cgst).toFixed(2);
        var sgst= parseFloat(sgst).toFixed(2);
        var grandtoatal= parseFloat(total) + parseFloat(cgst)+parseFloat(sgst);
        var grandtoatal= parseFloat(grandtoatal).toFixed(2);

          var gst='<div class="col-sm-6 col-12"> <label> CGST </label></div> <div class="col-sm-6 col-12"><label>'+cgst+'</label></div> <div class="col-sm-6 col-12 "> <label> SGST</label></div> <div class="col-sm-6 col-12"><label>'+sgst+'</label></div>';
       
     }else if(state_id!=32){
       var igst=Number(total*18/100);
       var igst= parseFloat(igst).toFixed(2);
       var grandtoatal= parseFloat(total) + parseFloat(igst);
       var grandtoatal= parseFloat(grandtoatal).toFixed(2);
      var gst='<div class="col-sm-6 col-12"> <label>IGST</label></div> <div class="col-sm-6 col-12"><label>'+igst+'</label></div> '
     } 

     $('#grandtotalamount').append('<div class="col-sm-12 col-12"> <div class="row clearfixed"><div class="col-sm-6 col-12"><label> Actual Price </label></div> <div class="col-sm-6 col-12"><label>'+totalamount+'.00</label></div>'+gst+'<div class="col-sm-6 col-12 "> <label> Total Amount </label></div> <div class="col-sm-6 col-12"><label>'+grandtoatal+'</label></div> </div></div>')
      }

    },
   complete:function(){
    // Hide image container
    $(".loader").hide();
},
 failure:function(result){
      
      alert('Information request failed: ' + textStatus, 'error');
    }


});

    

    });



// $('#invoice_pdf').click(excelexport);
// $('#invoice_print').click(excelexport);
// function DownloadExcel(link) {
//   var url = base_url+link;
//   window.open(url, '_blank');
  
// }
// function excelexport(){
  
//   var business_invoice_selectedid = $("#business_invoice_selectedid").val();
//   // var vendortypes = $("#vendortypes").val();
//   // var villano = $("#villano").val();
//   // var name = $("#name").val();
//   var export_type='';
//   var id = this.id;
  
//   if(id=='invoice_pdf'){
//     export_type=$("#invoice_pdf").val();  

//   }
//   if(id=='invoice_print'){
//     export_type=$("#invoice_print").val(); 
//   }
//   // var obj=  {business_invoice_selectedid: business_invoice_selectedid,export_type:export_type};
//   // var data = JSON.stringify(obj);
  
//   jQuery.ajax({
//     type: "POST",
//     url:url+"market-lead/TodayAllAppointmentsController/invoiceExport",
//     dataType: 'json',
//     data:{business_invoice_selectedid: business_invoice_selectedid,export_type:export_type},
//     success: function(result){
//       if(result.success===true){
//            $('#msg').hide().fadeIn('slow').delay(1350).fadeOut(2200);   
//           $("#msg").html("<div class='alert alert-success'>"+result.message+"</div>");
//           if(result.download_type=='pdf'){
//             DownloadExcel(result.data);
//             return false;
//           }else{
            
//               var printWindow = window.open('', '');
//               printWindow.document.write('<html><head><title>Invoice</title>');
//               printWindow.document.write('<link rel="stylesheet" href="'+url+'assets/vendors/css/vendor.bundle.base.css">');
//               printWindow.document.write('<link rel="stylesheet"  href="'+url+'assets/css/vertical-layout-light/style.css">');
//               printWindow.document.write('<link rel="stylesheet" href="'+url+'assets/css/custom.css">');
//               printWindow.document.write('</head><body >');
//               printWindow.document.write(result.data);
//               printWindow.document.write('</body></html>');
//               printWindow.document.close();
//               printWindow.print();
              
//           }
          
//       }
//       else{
//         //window.location.href= '';
//         setTimeout(function(){
//           $('#msg').html('<div class="alert alert-failure">No Data !...</div>');
//         },1000);
//         }
//     },
//     failure: function (result){
//       setTimeout(function(){
//         $('#msg').html('<div class="alert alert-failure">Something went wrong in App!...</div>');
//       },1000);
      
//     }
//   });
// }

// //==== send Email Receipt Start=== //

// $("#receipt_sendmail").click(function(){

// var business_receipt_selectedid = $('#business_receipt_selectedid').val();
//  var items =" ";
//    $.ajax({
//        type:"POST",
//        url:url+"market-lead/TodayAllAppointmentsController/receiptSendToMail",
//     dataType: 'json',
//     data:{business_receipt_selectedid:business_receipt_selectedid},
//     dataType: 'json',
// beforeSend: function(){
//     // Show image container
//     $(".loader").show();
// },
//  success: function(result){
      
//       if(result.success===true){
//         $('#receipt_sendmail_msg').hide().fadeIn('').delay(1000).fadeOut(2200);
//         $( "#receipt_sendmail_msg" ).html("<div class='alert alert-danger'>"+result.message+"</div>");
//    }
//   else if(result.success===false){
//         $('#receipt_sendmail_msg').hide().fadeIn('').delay(1000).fadeOut(2200);
//         $( "#receipt_sendmail_msg" ).html("<div class='alert alert-danger'>"+result.message+"</div>");
//       }
//     },
 
//   complete:function(){
//     // Hide image container
//     $(".loader").hide();
// },

//     failure: function (result){
//       $('#receipt_sendmail_msg').hide().fadeIn('slow').delay(1000).fadeOut(2200);
//       $( "#receipt_sendmail_msg").html("<div class='alert alert-danger'>Some thing went wrong try again ...</div>");      
//     } 
         
//       });

// });

// //==== send Email Receipt end=== //

// //==== send Email Invoice Start=== //

// $("#invoice_sendmail").click(function(){

// var business_invoice_selectedid = $('#business_invoice_selectedid').val();
//  var items =" ";
//    $.ajax({
//        type:"POST",
//        url:url+"market-lead/TodayAllAppointmentsController/invoiceSendToMail",
//     dataType: 'json',
//     data:{business_invoice_selectedid:business_invoice_selectedid},
//     dataType: 'json',
// beforeSend: function(){
//     // Show image container
//     $(".loader").show();
// },
//  success: function(result){
      
//       if(result.success===true){
//         $('#invoice_sendmail_msg').hide().fadeIn('').delay(1000).fadeOut(2200);
//         $( "#invoice_sendmail_msg" ).html("<div class='alert alert-danger'>"+result.message+"</div>");
//    }
//   else if(result.success===false){
//         $('#invoice_sendmail_msg').hide().fadeIn('').delay(1000).fadeOut(2200);
//         $( "#invoice_sendmail_msg" ).html("<div class='alert alert-danger'>"+result.message+"</div>");
//       }
//     },
 
//   complete:function(){
//     // Hide image container
//     $(".loader").hide();
// },

//     failure: function (result){
//       $('#receipt_sendmail_msg').hide().fadeIn('slow').delay(1000).fadeOut(2200);
//       $( "#receipt_sendmail_msg").html("<div class='alert alert-danger'>Some thing went wrong try again ...</div>");      
//     } 
         
//       });

// });

// //==== send Email Invoice end=== //

// $('#receipt_pdf').click(receiptexport);
// $('#receipt_print').click(receiptexport);

// function DownloadExcel(link) {
//   var url = base_url+link;
//   window.open(url, '_blank');
  
// }
// function receiptexport(){
  
//   var business_receipt_selectedid = $("#business_receipt_selectedid").val();
//   // var vendortypes = $("#vendortypes").val();
//   // var villano = $("#villano").val();
//   // var name = $("#name").val();
//   var export_type='';
//   var id = this.id;
  
//   if(id=='receipt_pdf'){
//     export_type=$("#receipt_pdf").val();  

//   }
//   if(id=='receipt_print'){
//     export_type=$("#receipt_print").val(); 
//   }
//   // var obj=  {business_receipt_selectedid: business_receipt_selectedid,export_type:export_type};
//   // var data = JSON.stringify(obj);
  
//   jQuery.ajax({
//     type: "POST",
//     url:url+"market-lead/TodayAllAppointmentsController/receiptExport",
//     dataType: 'JSON',
//     data:{business_receipt_selectedid: business_receipt_selectedid,export_type:export_type},
//     success: function(result){
//       if(result.success===true){
//            $('#msg').hide().fadeIn('slow').delay(1350).fadeOut(2200);   
//           $("#msg").html("<div class='alert alert-success'>"+result.message+"</div>");
//           if(result.download_type=='pdf'){
//             DownloadExcel(result.data);
//             return false;
//           }else{
            
//               var printWindow = window.open('', '');
//               printWindow.document.write('<html><head><title>Receipt</title>');
//               printWindow.document.write('<link rel="stylesheet" href="'+url+'assets/vendors/css/vendor.bundle.base.css">');
//               printWindow.document.write('<link rel="stylesheet"  href="'+url+'assets/css/vertical-layout-light/style.css">');
//               printWindow.document.write('<link rel="stylesheet" href="'+url+'assets/css/custom.css">');
//               printWindow.document.write('</head><body >');
//               printWindow.document.write(result.data);
//               printWindow.document.write('</body></html>');
//               printWindow.document.close();
//               printWindow.print();
              
//           }
          
//       }
//       else{
//         //window.location.href= '';
//         setTimeout(function(){
//           $('#msg').html('<div class="alert alert-failure">No Data !...</div>');
//         },1000);
//         }
//     },
//     failure: function (result){
//       setTimeout(function(){
//         $('#msg').html('<div class="alert alert-failure">Something went wrong in App!...</div>');
//       },1000);
      
//     }
//   });
// }



viewBusinessKeywords();   

        function viewBusinessKeywords(){
            $.ajax({
                type  : 'GET',
                url   : url+"Common/getBusinessKeywordslist",
                async : true,
                dataType : 'json',
                success : function(result){
     if(result.success==true){
        businesskeywordsview(result.data);
      
              }        
                }
            });
        }

  function businesskeywordsview(keywordlist){
    
       var items = "";
       var edititems = "";
       var i;
       var n = keywordlist.length;

for(i=0;i<n;i++) {
   items+= '<div class="col-md-4 col-12 form-group"> <input type="radio"  value='+keywordlist[i].id+' id="add_business_businesskeyword" name="add_business_businesskeyword"  style="display: inline;"> <span class="form-label" for="add_business_businesskeyword"> '+keywordlist[i].category_name+' </span></div>'

   edititems+= '<div class="col-md-4 col-12 form-group"> <input type="radio"  value='+keywordlist[i].id+' id="market_lead_add_packages_businesskeyword" name="market_lead_add_packages_businesskeyword"  style="display: inline;"> <span class="form-label" for="market_lead_add_packages_businesskeyword"> '+keywordlist[i].category_name+' </span></div>'

       }

         $("#addkeywordsbusiness").html(items);
         $("#addkeywordspackages").html(edititems);
  
  }

$("#add_keywords").validate({
     
     rules:{
        add_keywords_name :"required",
        add_keywords_category:"required"
     }
 });


$("#addkeywords").click(function() {
  
    if(!$("#add_keywords").valid())
   {
     return false;
   }
  
   var formData = new FormData($("#add_keywords")[0] );
     $.ajax({
      type:"POST",
    url:url+"Common/saveKeywords",
    dataType: 'json',
    data:formData,
    contentType: false, 
    cache: false,      
    processData:false,
  
  success: function(result){
      if(result.success==true){
        $('#keywords-addmsg').hide().fadeIn('slow').delay(1000).fadeOut(2200);    
          $( "#keywords-addmsg" ).html("<div class='alert alert-success'>"+result.message+"</div>");
        $('#add_keywords')[0].reset();
        setTimeout(function(){
               $('#AddkeywordsModal').modal("hide");
                    }, 5000); 
         viewBusinessKeywords(); 
      }
      else{
        $('#keywords-addmsg').hide().fadeIn('').delay(1000).fadeOut(2200);
        $( "#keywords-addmsg" ).html("<div class='alert alert-danger'>"+result.message+"</div>");
      }
    },
    
    failure: function (result){

      $('#keywords-addmsg').hide().fadeIn('slow').delay(1000).fadeOut(2200);
      $( "#keywords-addmsg" ).html("<div class='alert alert-danger'>Some thing went wrong try again ...</div>");      
    } 
        });

});


$("#search_packages_keyword").keyup(function() {
var search_business_keyword = $('#search_packages_keyword').val();
 var items =" ";
   $.ajax({
       type:"POST",
       url:url+"Common/SearchKeywordsForBusinessList",
    dataType: 'json',
    data:{search_business_keyword:search_business_keyword},
    dataType: 'json',

 success: function(result){
      
      if(result.success===true){

          businesskeywordsview(result.data)
   }
  else if(result.success===false){
        $('#search_packages_keywords-msg').hide().fadeIn('').delay(1000).fadeOut(2200);
        $( "#search_packages_keywords-msg" ).html("<div class='alert alert-danger'>"+result.message+"</div>");
      }
    },
    
    failure: function (result){
      $('#search_packages_keywords-msg').hide().fadeIn('slow').delay(1000).fadeOut(2200);
      $( "#search_packages_keywords-msg" ).html("<div class='alert alert-danger'>Some thing went wrong try again ...</div>");      
    } 
         
      });

});










$("#searchpackageswebcategory").click(function(){
  var search_website = $('#search_packages_website').val();
  searchdemowebsitesByCategoryForPackages(search_website);
});


  }); // document ready




$(document).on('click', '.marketeditbusiness a', function(e){

 $(".market_lead_todayAppointmentList_class").hide();
 // $(".addbusiness-class").hide();
 $(".market_lead_editbusiness-class").show();
 var id= $(this).attr("data-businessid");

$.ajax({
    type: "GET",
    url:url+'market-lead/TodayAllAppointmentsController/editBusinessByid/'+id,
    dataType: 'json',
 
  success:function(result){
      if(result.success===true)
      { 

        // alert(result.data[0].company_name);
        // $('#market_lead_edit_businessname_head').html(result.data[0].company_name);  

        $('#market_lead_edit_businessdata #market_lead_edit_business_addid').val(result.data[0].address_id);
        $('#market_lead_edit_businessdata #market_lead_edit_business_id').val(result.data[0].id);
        $('#market_lead_edit_businessdata #market_lead_edit_business_cname').val(result.data[0].company_name);
        $('#market_lead_edit_businessdata #market_lead_edit_business_hno').val(result.data[0].house_no);
        $('#market_lead_edit_businessdata #market_lead_edit_business_street').val(result.data[0].street);
        $('#market_lead_edit_businessdata #market_lead_edit_business_subarea').val(result.data[0].sub_area);
        $('#market_lead_edit_businessdata #market_lead_edit_business_area').val(result.data[0].area);
        $('#market_lead_edit_businessdata #market_lead_edit_business_landmark').val(result.data[0].landmark);
        $('#market_lead_edit_businessdata #market_lead_edit_business_city').val(result.data[0].city_id).prop("selected", true);
        $('#market_lead_edit_businessdata #market_lead_edit_business_state').val(result.data[0].state_id).prop("selected", true);
        $('#market_lead_edit_businessdata #market_lead_edit_business_pincode').val(result.data[0].pincode);

         $('#market_lead_edit_businessdata #market_lead_edit_business_pname').val(result.data[0].person_name);
         $('#market_lead_edit_businessdata #market_lead_edit_business_designation').val(result.data[0].person_designation);
         $('#market_lead_edit_businessdata #market_lead_edit_business_landlineno').val(result.data[0].landline_no);
         $('#market_lead_edit_businessdata #market_lead_edit_business_mobileno').val(result.data[0].mobile_no);
         $('#market_lead_edit_businessdata #market_lead_edit_business_altnemobileno').val(result.data[0].alt_mobile_no);
         $('#market_lead_edit_businessdata #market_lead_edit_business_email').val(result.data[0].email);

        $('#market_lead_edit_businessdata #market_lead_edit_business_gstcname').val(result.data[0].gst_company_name);
        $('#market_lead_edit_businessdata #market_lead_edit_business_cgstcname').val(result.data[0].gst_company_name);
        $('#market_lead_edit_businessdata #market_lead_edit_business_gstno').val(result.data[0].gst_number);
        $('#market_lead_edit_businessdata #market_lead_edit_business_cgstno').val(result.data[0].gst_number);
        $('#market_lead_edit_businessdata #market_lead_edit_business_gststate').val(result.data[0].gst_state);
        $('#market_lead_edit_businessdata #market_lead_edit_business_gstpincode').val(result.data[0].gst_pincode);
        $('#market_lead_edit_businessdata #market_lead_edit_business_gstpanno').val(result.data[0].gst_pan_no);
        $('#market_lead_edit_businessdata #market_lead_edit_business_gstaddress').val(result.data[0].gst_address);
        $('#market_lead_edit_businessdata #market_lead_edit_business_status').val(result.data[0].business_status_id).prop("selected", true);


        $('#market_lead_edit_businessdata #market_lead_edit_business_website').val(result.data[0].website_url);
        $('#market_lead_edit_businessdata #market_lead_edit_business_facebook').val(result.data[0].facebook_url);
        $('#market_lead_edit_businessdata #market_lead_edit_business_twitter').val(result.data[0].twitter_url);
        $('#market_lead_edit_businessdata #market_lead_edit_business_youtube').val(result.data[0].youtube_url);
        $('#market_lead_edit_businessdata #market_lead_edit_business_linkedin').val(result.data[0].linkedin_url);
        $('#market_lead_edit_businessdata #market_lead_edit_business_instagram').val(result.data[0].instagram_url);

        $('#market_lead_edit_businessdata #market_lead_edit_business_owner1name').val(result.editowner[0].owner_name);
        $('#market_lead_edit_businessdata #market_lead_edit_business_owner1role').val(result.editowner[0].owner_role);
        $('#market_lead_edit_businessdata #market_lead_edit_business_owner1mobile').val(result.editowner[0].owner_mobile);
        $('#market_lead_edit_businessdata #market_lead_edit_business_owner1email').val(result.editowner[0].owner_email);

        $('#market_lead_edit_businessdata #market_lead_edit_business_owner2name').val(result.editowner[1].owner_name);
        $('#market_lead_edit_businessdata #market_lead_edit_business_owner2role').val(result.editowner[1].owner_role);
        $('#market_lead_edit_businessdata #market_lead_edit_business_owner2mobile').val(result.editowner[1].owner_mobile);
        $('#market_lead_edit_businessdata #market_lead_edit_business_owner2email').val(result.editowner[1].owner_email);
      
         

         $('#market_lead_edit_businessdata #market_lead_edit_business_lat').val(result.data[0].latitude);
         $('#market_lead_edit_businessdata #market_lead_edit_business_long').val(result.data[0].longitude);

  //  var latitude=result.data[0].latitude;
  //  var longitude=result.data[0].longitude;
  // var myLatLng = {lat:latitude, lng:longitude};
  // var map = new google.maps.Map(document.getElementById('editdvMap'), {
  //   zoom: 4,
  //   center: myLatLng
  // });

  // var marker = new google.maps.Marker({
  //   position: myLatLng,
  //   map: map,
  //   title: 'Hello World!'
  // });




   if(result.data[0].photo!=null){
     $("#businessimage").html('<img src="'+url+result.data[0].photo+ '" width="200px"  height="100px" alt=" photo" />');
   }else{
    $("#businessimage").html('<img src="'+url+'assets/images/no_image.png" width="200px"  height="100px" alt=" photo" />')
   }



      }else{
            alert('request failed', 'error');
      }

    },
   
 
 fail:function(result){
      
      alert('Information request failed: ' + textStatus, 'error');
    }

});



});

var businesseditform = $("#market_lead_edit_businessdata");
businesseditform.validate({
    errorPlacement: function errorPlacement(error, element) { element.before(error); },
    rules: {
      market_lead_edit_business_city :"required",
      market_lead_edit_business_state :"required",
      market_lead_edit_business_cname :"required",
      market_lead_edit_business_street:"required", 
      market_lead_edit_business_area:"required",
      market_lead_edit_business_pincode:{number:true,minlength:6, maxlength:6},
      market_lead_edit_business_pname:"required",
      market_lead_edit_business_designation:"required",
      market_lead_edit_business_landlineno:{number:true,minlength:8, maxlength:16},
      market_lead_edit_business_mobileno:{required:true,number:true, number:true,minlength:10, maxlength:10},
      market_lead_edit_business_altnemobileno:{minlength:10, maxlength:10},
      market_lead_edit_business_condition:"required",
      market_lead_edit_business_email:{required:true,email: true },
      market_lead_edit_business_cgstcname: {equalTo: "#market_lead_edit_business_gstcname"},
      market_lead_edit_business_cgstno: {equalTo: "#market_lead_edit_business_gstno"},
      market_lead_edit_business_debitcardno:{number:true,minlength:5, maxlength:18},
      market_lead_edit_business_creditcardno:{number:true,minlength:5, maxlength:18},
      market_lead_edit_business_accountno:{number:true,minlength:5, maxlength:20},
      market_lead_edit_business_caccountno: {number:true,minlength:5, maxlength:20,equalTo: "#market_lead_edit_business_accountno"},
      market_lead_edit_business_cacholdername: { equalTo: "#market_lead_edit_business_acholdername"},
      // market_lead_edit_business_owner1name:"required",
      // market_lead_edit_business_owner1role:"required",
      market_lead_edit_business_owner1mobile:{number:true,minlength:10, maxlength:10},
      market_lead_edit_business_owner1email:{email: true },
      market_lead_edit_business_owner2mobile:{minlength:10, maxlength:10},
      market_lead_edit_business_owner2email:{email: true },
      // market_lead_edit_business_status:"required",
      

    }
});

businesseditform.children("div").steps({
    headerTag: "h3",
    bodyTag: "section",
    transitionEffect: "slideLeft",
    onStepChanging: function (event, currentIndex, newIndex)
    {
        businesseditform.validate().settings.ignore = ":disabled,:hidden";
          
        return businesseditform.valid();
        
    },
    onFinishing: function (event, currentIndex)
    {
        var result = $('ul[aria-label=Pagination]').children().find('a');
        $(result).each(function ()  { 
           if ($(this).text() == 'Finish') {
               $(this).attr('disabled', true);
               $(this).css('background', 'green');
           } 
        });
        businesseditform.validate().settings.ignore = ":disabled";
        return businesseditform.valid();
    },
    onFinished: function (event, currentIndex)
    {

    var formData = new FormData($("#market_lead_edit_businessdata")[0] );
     $.ajax({
      type:"POST",
    url:url+"market-lead/TodayAllAppointmentsController/updateBusinessData",
    dataType: 'json',
    data:formData,
    contentType: false, 
    cache: false,      
    processData:false,
    
    beforeSend: function(){
    // Show image container
    $(".loader").show();
},
     

      success: function(result){
      
      if(result.success==true){

        $('#businessdata-editmsg').hide().fadeIn('slow').delay(1000).fadeOut(2200);   
        $( "#businessdata-editmsg" ).html("<div class='alert alert-success'>"+result.message+"</div>");
        $('#market_lead_edit_businessdata')[0].reset();

        window.setTimeout(function(){location.reload()},3000)
       
      }
      else{
        $('#businessdata-editmsg').hide().fadeIn('').delay(1000).fadeOut(2200);
        $( "#businessdata-editmsg" ).html("<div class='alert alert-danger'>"+result.message+"</div>");
      }
    },
    
      complete:function(){
    // Hide image container
    $(".loader").hide();
}, 
    failure: function (result){

      $('#businessdata-editmsg').hide().fadeIn('slow').delay(1000).fadeOut(2200);
      $( "#businessdata-editmsg" ).html("<div class='alert alert-danger'>Some thing went wrong try again ...</div>");     
    } 
         
      });

    }
});




$("#marketinglead_packages_generated_opt").click(function() {
var market_lead_add_packages_companyname = $("#market_lead_add_packages_companyname").val();
var add_business_payment_mode =$("input:radio[name=add_business_payment_mode]:checked").val();    
// var add_business_payment_mode = $("#add_business_payment_mode").val();
var market_lead_add_packages_total = $("#market_lead_add_packages_total").val();
var market_lead_add_packages_grandtotal = $("#market_lead_add_packages_grandtotal").val();
   $.ajax({
    type:"POST",
    url:url+"Welcome/OtpSendToMobileForpackageMarketingLead",
    dataType: 'json',
    data:{market_lead_add_packages_companyname:market_lead_add_packages_companyname,add_business_payment_mode:add_business_payment_mode,market_lead_add_packages_total:market_lead_add_packages_total,market_lead_add_packages_grandtotal:market_lead_add_packages_grandtotal},
    dataType: 'json',

 success: function(result){
      
      if(result.success==true){
          alert(result.message);
           $('#marketinglead_package_otpverficationmodal').modal('show');
        }
  else if(result.success==false){
        alert(result.message);
      }
    },
    
    failure: function (result){
      alert("Some thing went wrong try again ...");
    } 
         
      });

});

// }


$("#marketingleadpackageotpverification").click(function() {

var marketinglead_package_mobileOtp = $("#marketinglead_package_mobileOtp").val();
   $.ajax({
       type:"POST",
       url:url+"Welcome/OtpVerficationToMobileForpackageMarketingLead",
    dataType: 'json',
    data:{marketinglead_package_mobileOtp:marketinglead_package_mobileOtp},
    dataType: 'json',
 success: function(result){
      
      if(result.success==true){
        $('#marketinglead_add_package_otp').val(marketinglead_package_mobileOtp);
        $('#marketinglead_package_otpverficationmodal').modal('hide');    
        alert(result.message);
   }
  else if(result.success===false){
       alert(result.message);
      }
    },
    
    failure: function (result){
     alert("Some thing went wrong try again ...");
    } 
         
      });

});


//=== marketlead_listofbusiness  ==//

$(document).on('click', '.marketlead_listofbusiness a', function(e){
 var id= $(this).attr("data-businessid");
 var name=$(this).attr("data-businessname");
  // alert("kk");
$("#companyname").html(name);
$(".market_lead_todayAppointmentList_class").hide();
$(".marketlead_listofbusiness-class").show();
$.ajax({
    type: "GET",
    url:url+'market-lead/TodayAllAppointmentsController/listOfBusiness/'+id,
    dataType: 'json',
 beforeSend: function(){
    // Show image container
    $(".loader").show();
},
  success:function(result){
      if(result.success===true)
      { 
         var role=result.role; 
         if ( $.fn.DataTable.isDataTable('#marketlead_listofbusinesstable')) {
         $('#marketlead_listofbusinesstable').DataTable().destroy();
         }  
         $('#marketlead_listofbusinesstable tbody').empty();

         var data=result.data; 
         var table = $('#marketlead_listofbusinesstable').DataTable({
        
         paging: true,
         searching: true,
         columns: [
      {data: 'id',title: 'Sno'},
      {data: 'package_name',title:'Packages'},
      {data: 'campaign_name',title:'Campaign'},
      {data: 'gstgrand_total_amount',title:'Grand Total'},
      {data: 'created_on',title:'Date'},
      {data: 'status',title:'Project Status'},
      {data: null,
          'title' : 'Action',
          "sClass" : "center",
          mRender: function (data, type, row) {
           
                   return '<button class="btn btn-info btn-sm business_receipt"  id="business_receipt" title="Receipt" ><a data-selectedid="'+data.id+'" data-selectedname="' +data.company_name+ '" style="color:#FFFFFF;"><i class="mdi mdi-file-document"></i></a></button>&nbsp; <button class="btn btn-danger btn-sm marketlead_payment_pending"  id="marketlead_payment_pending" title="Payment Pending" ><a data-selectedid="'+data.id+'" data-selectedname="' +data.company_name+ '" style="color:#FFFFFF;"><i class="mdi mdi-file-document"></i></a></button>&nbsp;'

        } }
     ]
   
 });

table.rows.add(data).draw();
      }else{
            alert('request failed', 'error');
      }

    },
   
  complete:function(){
    // Hide image container
    $(".loader").hide();
}, 
 fail:function(result){
      
      alert('Information request failed: ' + textStatus, 'error');
    }

});

});

/* ==== payment pending start  ===*/

$(document).on('click', '.marketlead_payment_pending a', function(e){
 var id= $(this).attr("data-selectedid");
 var name=$(this).attr("data-selectedname");

 $(".marketlead_listofbusiness-class").hide();
$.ajax({
    type: "GET",
    url:url+'market-lead/TodayAllAppointmentsController/BusinessPaymentPending/'+id,
    dataType: 'json',
 
  success:function(result){
      if(result.success===true)
      { 

        $(".paymentpending-class").show();
        $('#add_marketlead_paymentpending #marketlead_paymentpending_package_id').val(result.data[0].business_package_id);
        $('#add_marketlead_paymentpending #marketlead_paymentpending_marketlead_id').val(result.data[0].business_id);

        $('#add_marketlead_paymentpending #add_paymentpending_status').val(result.data[0].business_status_id).prop('selected', true);

        $('#marketlead_paymentpending_company_name').html(result.data[0].company_name);
        $('#marketlead_paymentpending_person_name').html(result.data[0].person_name);
        $('#marketlead_paymentpending_designation').html(result.data[0].person_designation);
        $('#marketlead_paymentpending_mobileno').html(result.data[0].mobile_no);
        $('#marketlead_paymentpending_email').html(result.data[0].email);
        $('#marketlead_paymentpending_address').html(result.data[0].address);
       
        $('#marketlead_paymentpending_subtotal').html(result.data[0]. total_amount);
        $('#marketlead_paymentpending_discount').html(result.data[0].discount_amount);
        $('#marketlead_paymentpending_total').html(result.data[0].grand_total_amount);

       if(result.data[0].cgst_amount!=null && result.data[0].sgst_amount!=null && result.data[0].cgst_amount!=0 && result.data[0].sgst_amount!=0){
            var gst=Number(Number(result.data[0].cgst_amount)+Number(result.data[0].sgst_amount));
         }else if(result.data[0].igst_amount!=null ){
           var gst=Number(result.data[0].igst_amount);
         }
         
        $("#marketlead_paymentpending_gst").html(gst);
        $("#marketlead_paymentpending_gstgrandtotal").html(result.data[0].gstgrand_total_amount);
        $("#receipt_payment_methode").html(result.data[0].paymenttype_name);
        $("#receipt_order_id").html(result.data[0].order_id);  


        for(var i=0; i<result.campaigndata.length;i++){
       $("#marketlead_paymentpending_packages_table > tbody").append('<tr><td>'+result.campaigndata[i][0].campaign_name+'</td><td>'+result.campaigndata[i][0].campaign_amount+'</td></tr>');
               }             
    
          
    for(var j=0; j<result.packagesdata.length;j++){
       $("#marketlead_paymentpending_packages_table > tbody").append('<tr><td>'+result.packagesdata[j][0].package_name+'</td><td>'+result.packagesdata[j][0].package_amount+'</td></tr>');
    } 

   var transctiontotal=0;

    for(var j=0; j<result.paymenttransction.length;j++){

       $("#marketlead_paymentpending_transctiondetails > tbody").append('<tr><td>'+result.paymenttransction[j].order_id+'</td><td>'+result.paymenttransction[j].transaction_amount+'</td><td>'+result.paymenttransction[j].paymenttype_name+'</td><td>'+result.paymenttransction[j].transaction_status+'</td></tr>');

       if(result.paymenttransction[j].transaction_status=="SUCCESS"){ 
         var amount=result.paymenttransction[j].transaction_amount;
            transctiontotal += parseFloat(amount);
          }

    } 

      $("#marketlead_paymentpending_transction_gstgrandtotal").html(result.data[0].gstgrand_total_amount);
      var transctiontotal= parseFloat(transctiontotal).toFixed(2);
      $("#marketlead_paymentpending_transction_grandtotal").html(transctiontotal);
      
        var pendingtotal= parseFloat(result.data[0].gstgrand_total_amount)-parseFloat(transctiontotal);
        var pendingtotal= parseFloat(pendingtotal).toFixed(2);

        $("#marketlead_paymentpending_transction_pendingtotal").html(pendingtotal);
        $("#marketlead_paymentpending_transction_pendingtotal_showingpending").html(pendingtotal);
        $("#marketlead_paymentpending_pendingtotal").val(pendingtotal);
       
      }else{
            alert('request failed', 'error');
      }

    },
 
 fail:function(result){
      
      alert('Information request failed: ' + textStatus, 'error');
    }

});


});



var paymentpendingaddform = $("#add_marketlead_paymentpending");
paymentpendingaddform.validate({
    errorPlacement: function errorPlacement(error, element) { element.before(error); },
    rules: {
      // add_employees_city :"required",
      // add_employees_state :"required",

    }
});

paymentpendingaddform.children("div").steps({
    headerTag: "h3",
    bodyTag: "section",
    transitionEffect: "slideLeft",
    onStepChanging: function (event, currentIndex, newIndex)
    {
        paymentpendingaddform.validate().settings.ignore = ":disabled,:hidden";
        return paymentpendingaddform.valid();
    },
    onFinishing: function (event, currentIndex)
    {
        paymentpendingaddform.validate().settings.ignore = ":disabled";
        return paymentpendingaddform.valid();
    },
    onFinished: function (event, currentIndex)
    {
         
    var formData = new FormData($("#add_marketlead_paymentpending")[0] );
     $.ajax({
      type:"POST",
     url:url+"market-lead/TodayAllAppointmentsController/savePaymentpendingData",
    dataType: 'json',
    data:formData,
    contentType: false, 
    cache: false,      
    processData:false,
beforeSend: function(){
    // Show image container
    $(".loader").show();
},

      success: function(result){
      
      if(result.success==true){

        $('#paymentpendingdata-addmsg').hide().fadeIn('slow').delay(1000).fadeOut(2200);   
        $( "#paymentpendingdata-addmsg" ).html("<div class='alert alert-success'>"+result.message+"</div>");
        $('#add_marketlead_paymentpending')[0].reset();
      
      }
      else{
        $('#paymentpendingdata-addmsg').hide().fadeIn('').delay(1000).fadeOut(2200);
        $( "#paymentpendingdata-addmsg" ).html("<div class='alert alert-danger'>"+result.message+"</div>");
      }
    },
     complete:function(){
    // Hide image container
    $(".loader").hide();
}, 
    
    failure: function (result){

      $('#paymentpendingdata-addmsg').hide().fadeIn('slow').delay(1000).fadeOut(2200);
      $( "#paymentpendingdata-addmsg" ).html("<div class='alert alert-danger'>Some thing went wrong try again ...</div>");     
    } 
         
      });

    }
});


/* ==== payment pending ends  ===*/

/* ==== Receipt ends  ===*/

$(document).on('click', '.business_receipt a', function(e){
 var id= $(this).attr("data-selectedid");
 var name=$(this).attr("data-selectedname");
 $(".marketlead_listofbusiness-class").hide();
 $(".listofreceipt-class").show();
$.ajax({
    type: "GET",
    url:url+'Common/BusinessReceiptList/'+id,
    dataType: 'json',
  success:function(result){
      if(result.success===true)
      { 
        if ( $.fn.DataTable.isDataTable('#listofreceipttable')) {
         $('#listofreceipttable').DataTable().destroy();
         }  
         $('#listofreceipttable tbody').empty();

         var data=result.data; 
         var table = $('#listofreceipttable').DataTable({
        
         paging: true,
         searching: true,
         columns: [
      {data: 'id',title: 'Sno'},
      {data: 'created_on',title:'Date'},
      {data: 'order_id',title:'Order Id'},
      {data: 'paymenttype_name',title:'Payment Type'}, 
      {data: 'transaction_amount',title:'Paid Amount'}, 
      {data: 'transaction_status',title:'Transction Status'},
      {data: null,
          'title' : 'Action',
          "sClass" : "center",
          mRender: function (data, type, row) {
                         return '<button class="btn btn-info btn-sm business_receipt_byid"  id="business_receipt_byid" title="Receipt" ><a data-selectedid="'+data.id+'" data-selectedname="' +data.company_name+ '" style="color:#FFFFFF;"><i class="mdi mdi-file-document"></i></a></button>&nbsp;'
        } }
     ]
   
 });

table.rows.add(data).draw();
       
      }else{
            alert('request failed', 'error');
      }
    },
 fail:function(result){
      
      alert('Information request failed: ' + textStatus, 'error');
    }

});


});



$(document).on('click', '.business_receipt_byid a', function(e){
 var id= $(this).attr("data-selectedid");
 var name=$(this).attr("data-selectedname");
 $(".listofreceipt-class").hide();
$.ajax({
    type: "GET",
    url:url+'Common/BusinessReceipt/'+id,
    dataType: 'json',
  success:function(result){
      if(result.success===true)
      { 
        $(".receipt-class").show();
        $('#export_receipt #business_receipt_selectedid').val(result.data[0].id);
        // alert(result.data[0].id);
        $('#receipt_date').html(result.data[0].created_on);
        $('#receipt_number').html(result.data[0].id);
        $('#receipt_company_name').html(result.data[0].company_name);
        $('#receipt_company_address').html(result.data[0].address);
        $('#receipt_company_city').html(result.data[0].cityname);
        $('#receipt_comapy_state').html(result.data[0].state_name); 
        $('#receipt_person_designation').html(result.data[0].person_designation); 
        $('#receipt_person_name').html(result.data[0].person_name); 
        $('#receipt_email').html(result.data[0].email); 
        $('#receipt_mobile_no').html(result.data[0].mobile_no);
        $('#receipt_total_payment').html(result.data[0].grand_total_amount);
        $('#receipt_bank_name').html(result.data[0].bank_name);
        
        // $('#receipt_pay_date').html(result.data[0].created_on);
       //  $("#receipt_sub_total").html(result.data[0].total_amount);
       //  $("#receipt_discount_amount").html(result.data[0].discount_amount);
       //  $("#receipt_total_amount").html(result.data[0].grand_total_amount);
       // if(result.data[0].cgst_amount!=null && result.data[0].sgst_amount!=null){
       //  var gst=Number(Number(result.data[0].cgst_amount)+Number(result.data[0].sgst_amount));
       // }else if(result.data[0].igst_amount!=null ){
       //   var gst=Number(result.data[0].igst_amount);
       // }
       //  $("#receipt_gst").html(gst);
       //  $("#receipt_grand_total").html(result.data[0].gstgrand_total_amount);

           // alert(result.data[0].transaction_amount);
        $("#receipt_transaction_amount").html(result.data[0].transaction_amount);
        $("#receipt_transaction_status").html(result.data[0].transaction_status);
        $("#receipt_payment_methode").html(result.data[0].paymenttype_name);
        $("#receipt_order_id").html(result.data[0].order_id);

      // $("#receipt_marketing_name").html(result.data[0].marketing_name);
       
      }else{
            alert('request failed', 'error');
      }
    },
 fail:function(result){
      
      alert('Information request failed: ' + textStatus, 'error');
    }

});

});

/* ==== Receipt ends  ===*/

}); // document ready
