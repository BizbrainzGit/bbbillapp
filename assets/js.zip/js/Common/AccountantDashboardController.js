
var url=base_url.baseurl;

AccountantProjectviewListData();   
function AccountantProjectviewListData(){
    $.ajax({
    type : 'GET',
    url : url+"accountant/AccountantHome/AccountantProjectList",
    async : true,
    dataType : 'json',
    success : function(result){
      if(result.success===true){
        AccountantProjectViewList(result.data,result.role)
      } 

    }
    });
}

 function AccountantProjectViewList(projectlist,roleslist){

   if ( $.fn.DataTable.isDataTable('#accountantprojectslisttable')) {
         $('#accountantprojectslisttable').DataTable().destroy();
         }  
         $('#accountantprojectslisttable tbody').empty();
          var data=projectlist;
          var role=roleslist;
         var table = $('#accountantprojectslisttable').DataTable({
         paging: true,
         searching: true,
         columns: [
      {data: 'id',title: 'S No'},
      {data: 'business_id',title:'Project ID'},
      {data: 'company_name',title:'Project Name'},
      {data: 'person_name',title: 'Client Name'},
      {data: 'mobile_no',title: 'Mobile No.'},
      {data: 'tele_name',title: 'TME Name.'},
      {data: 'marketing_name',title: 'ME Name.'},
      {data: 'paymenttype_name',title: 'Payment Modes'},
      {data: 'status',title: 'Project Status'},
      {data: null,
           'title' : 'Action',
           "sClass" : "center",
           "width":"20%",
           


           mRender: function (data, type, row) {
           if(role=="Accountant"){

             return '<input class="checkbox" type="checkbox" name="edit_business_condition" id="edit_business_condition" style="font-size:20px">'

          }
           } }
           ] 
       });
 
table.rows.add(data).draw();
 
 }
