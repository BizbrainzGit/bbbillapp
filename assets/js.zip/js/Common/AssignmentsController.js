var url=base_url.baseurl;


$(document).ready(function(){

// ==== TeleMarketing Role Start == //  
assignmentListView()
 function assignmentListView(){
            $.ajax({
                type  : 'GET',
                url   : url+"tele-market/AssignmentsController/SearchBusinessTelemarket",
                async : true,
                dataType : 'json',
                success : function(result){
                 if(result.success===true){
                  assignmentView(result.data);
                  }        
                }

            });

        }

function assignmentView(AssignmentsList){

    if ( $.fn.DataTable.isDataTable('#assignmentstable')) {
         $('#assignmentstable').DataTable().destroy();
         }  
         $('#assignmentstable tbody').empty();

         var data=AssignmentsList; 
         var table = $('#assignmentstable').DataTable({
        
         paging: true,
         searching: true,
         columns: [
      {data: 'id',title: 'Sno'},
      {data: 'company_name',title:'Company Name'},
      {data: 'person_name',title:'Person Name'},
      {data: 'mobile_no',title:'Mobile No.'},
      {data: 'email',title:'Email'},
      {data: 'address_id',title:'Address'},
      {data: 'status_value',title:'Status'},
      {data: null,
           'title' : 'Message',
           "sClass" : "center",
           mRender: function (data, type, row) {
    return '<button class="btn btn-info btn-sm assignmentaddview mt-2" id="assignmentaddview"><a data-assignmentid="'+data.id+'" data-assignmentname="' +data.company_name+ '" style="color:#FFFFFF;"><i class="mdi mdi-view-array"></i></a></button>'
           } }
        ]

       });

  table.rows.add(data).draw();
   
}

$("#assignmentadd").click(function() {
var business_id=$('#assignmentadd_business_id').val();
  $('#add_business_id').val(business_id);
$.ajax({
    type: "GET",
    url:url+'tele-market/AssignmentsController/getMarketingUsersForAssignments/'+business_id,
    dataType: 'json',
 
  success:function(result){
      if(result.success==true)
      { 
   var items
   items+="<option value=''>--Select Marketing Users--</option>";
      $.each(result.data,function(index,itemlist){ 
      	items+="<option value='"+itemlist.user_id+"'>"+itemlist.user_name+" ("+itemlist.designation+")</option>";
      });
      
      $("#add_assignment_markrting_user").html(items);
      }else{
            alert('request failed', 'error');
      }

    },
 
 fail:function(result){
      alert('Information request failed: ' + textStatus, 'error');
    }

});

});

$("#add_assignment").validate({
     
     rules:{
        add_message :"required",
        add_assignment_markrting_user:"required",
        add_appointment_date:"required",
     }
 });

$("#addassignment").click(function() {

	  if(!$("#add_assignment").valid())
	 {
		 return false;
	 }
	
   var formData = new FormData($("#add_assignment")[0] );
     $.ajax({
      type:"POST",
    url:url+"tele-market/AssignmentsController/saveAssignments",
    dataType: 'json',
    data:formData,
    contentType: false, 
    cache: false,      
    processData:false,
    
     beforeSend: function(){
        // Show image container
        $(".loader").show();
    }, 

      success: function(result){
			
			if(result.success==true){
				$('#assignment-addmsg').hide().fadeIn('slow').delay(1000).fadeOut(2200);		
			    $( "#assignment-addmsg" ).html("<div class='alert alert-success'>"+result.message+"</div>");
				$('#add_assignment')[0].reset();
				setTimeout(function(){
               $('#AddassignmentModal').modal("hide");
                    }, 5000);	

           assignmentListView()
				 
			}
			else if(result.success===false){
				$('#assignment-addmsg').hide().fadeIn('').delay(1000).fadeOut(2200);
				$( "#assignment-addmsg" ).html("<div class='alert alert-danger'>"+result.message+"</div>");
			}
		},
    
	   complete:function(){
    // Hide image container
    $(".loader").hide();
},
		failure: function (result){

			$('#assignment-addmsg').hide().fadeIn('slow').delay(1000).fadeOut(2200);
			$( "#assignment-addmsg" ).html("<div class='alert alert-danger'>Some thing went wrong try again ...</div>");		  
		}	

      });


});


 $(document).on('click', '.assignmentaddview a', function(e){
 var id= $(this).attr("data-assignmentid");
 var name=$(this).attr("data-assignmentname");
 $("#assignmentadd_business_id").val(id)
$("#assignment_companyname").html(name);
$(".assignmentadd-class").hide();
$(".assignmentaddview-class").show();

$.ajax({
    type: "GET",
    url:url+'tele-market/AssignmentsController/AssignmentsviewList/'+id,
    dataType: 'json',
 
  success:function(result){
      if(result.success===true)
      { 
               
          if ( $.fn.DataTable.isDataTable('#assignmentsaddtable')) {
				 $('#assignmentsaddtable').DataTable().destroy();
				 }	
				 $('#assignmentsaddtable tbody').empty();

				 var data=result.data; 
				 var table = $('#assignmentsaddtable').DataTable({
				
				 paging: true,
				 searching: true,
				 columns: [
		  {data: 'id',title: 'Sno'},
		  {data: 'appointment_date',title:'Appointment <br> Date.'},
		  {data: 'marketing_name',title:'Marketing Name'},
		  // {data: 'tele_name',title:'Tele-caller Name'},
		  {data: 'work_assigned_date',title:'Work Assigned <br> Date'},
		  {data: 'message',title:'Message'},
		  // {data: null,
				// 	 'title' : 'Message',
				// 	 "sClass" : "center",
				// 	 mRender: function (data, type, row) {
    // return '<button class="btn btn-primary btn-sm assignmentadd" data-toggle="modal" id="assignmentadd" data-target="#AddassignmentModal"><a data-assignmentid="'+data.id+'" data-campaignname="' +data.company_name+ '" style="color:#FFFFFF;"><i class="mdi mdi-message-draw"></i></a></button>&nbsp;'
				// 	 } }
				]

			 });
        table.rows.add(data).draw();

       
      }else{
            alert('request failed', 'error');
      }

    },
   
 
 fail:function(result){
      
      alert('Information request failed: ' + textStatus, 'error');
    }

});

});


$("#search_telemarketing_business").validate({
     
     rules:{
        // search_business_cname :"required",
        // search_business_city :"required",
      
     }
 });

$("#searchtelemarketingbusiness").click(function() {
  
    if(!$("#search_telemarketing_business").valid())
   {
     return false;
   }
  
   var formData = new FormData($("#search_telemarketing_business")[0] );
     $.ajax({
      type:"POST",
    url:url+"tele-market/AssignmentsController/SearchBusinessTelemarket",
    dataType: 'json',
    data:formData,
    contentType: false, 
    cache: false,      
    processData:false,


      success: function(result){
      
      if(result.success==true){
    assignmentView(result.data);

      }
      else if(result.success===false){
        alert('Information request failed:error, Please try Again....');
      }
    },
    
    failure: function (result){

      alert('Information request failed: error, Please try Again....');
    } 

      });


});

// ==== TeleMarketing Role ends == //


}); // document ready ///



$(function(){
  
     var items="";
     $.getJSON(url+"tele-market/TodayAllAppointmentsController/TodayAppointForTelemarketing", function(campaignList){
      $.each(campaignList,function(index,itemlist)
     {

     if ( $.fn.DataTable.isDataTable('#todayallapptable')) {
         $('#todayallapptable').DataTable().destroy();
         }  
         $('#todayallapptable tbody').empty();

         var data=itemlist; 
         var table = $('#todayallapptable').DataTable({
        
         paging: true,
         searching: true,
         columns: [
      {data: 'id',title: 'S No.'},
      {data: 'personname',title:'Appointment Person Name'},
      {data: 'appointment_date',title:'Appointment Date'},
      {data: 'appointment_time',title:'Appointment Time'},
      {data: 'company_name',title:'Company Name'},
      {data: 'person_name',title:'Contact Person Name'},
      {data: 'mobile_no',title:'Contact Person Phone'},
      {data: 'message',title:'Message'},
      
        ],

  

       });

table.rows.add(data).draw();
 
     
      }); 
}); 
 });




