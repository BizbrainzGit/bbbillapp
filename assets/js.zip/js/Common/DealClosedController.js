var url=base_url.baseurl;



BusinessDealclosedList();   
function BusinessDealclosedList(){
    $.ajax({
    type : 'GET',
    url : url+"DealClosedController/SearchDealClosedlist",
    async : true,
    dataType : 'json',
    success : function(result){
      if(result.success==true){
       
        BusinessDealclosedListData(result.data)
      } 

    }
    });
}


function BusinessDealclosedListData(businesslist){
      
       // var role=roles ;

   if ( $.fn.DataTable.isDataTable('#dealclosedtable')) {
         $('#dealclosedtable').DataTable().destroy();
         }  
         $('#dealclosedtable tbody').empty();
          
          var data=businesslist;
         var table = $('#dealclosedtable').DataTable({
         
         paging: true,
         searching: true,
         columns: [
      {data: 'id',title: 'S No.'},
      {data: 'company_name',title:'Company Name'},
      // {data: 'area',title: 'Area'},
      {data: 'cityname',title: 'City Name'},
      {data: 'state_name',title: 'State Name'},
      {data: 'status_value',title:'Business Status'},
    //   {data: null,
    //        'title' : 'Action',
    //        "sClass" : "center",
    //        "width":"20%",
           


    //        mRender: function (data, type, row) {
    //        if(role=="Marketing-Lead"){

    //          return '<button class="btn btn-info btn-sm mt-2 status_edit" data-toggle="modal" id="status_edit" data-target="#EditstatusModal" title="Status Edit"><a data-businessid="'+data.id+'" data-businessname="' +data.company_name+ '" style="color:#ffffff"> <i class="mdi mdi-pencil-box"></i> </a></button> &nbsp;                                                                                                      <button class="btn btn-info btn-sm mt-2  editbusiness"  id="businessdata_edit" title="Business Edit" style="color:#0066ff"><a data-businessid="'+data.id+'" data-businessname="' +data.company_name+ '"  style="color:#ffffff"> <i class="mdi mdi-grease-pencil"></i> </a></button>&nbsp;                                                                           <button class="btn btn-info btn-sm mt-2 selectedpackages" title="Select Package"><a data-businessid="'+data.id+'" data-businessname="' +data.company_name+ '"style="color:#ffffff" data-businessstate_id="'+data.state_id+'" > <i class="mdi mdi-package-variant" data-name="mdi-package-variant"></i> </a></button>&nbsp;                                                                                         <button class="btn btn-primary btn-sm mt-2 listofbusiness" title="Payment History"><a data-businessid="'+data.id+'" data-businessname="' +data.company_name+ '" style="color:#ffffff" > <i class="mdi mdi-wallet" data-name="mdi-package-variant"></i> </a></button>'

    //       }else if(role=="Marketing"){
    //            return '<button class="btn btn-info btn-sm mt-2 status_edit" data-toggle="modal" id="status_edit" data-target="#EditstatusModal" title="Status Edit"><a data-businessid="'+data.id+'" data-businessname="' +data.company_name+ '" style="color:#ffffff"> <i class="mdi mdi-pencil-box"></i> </a></button> &nbsp;                                                                                                    <button class="btn btn-info btn-sm mt-2 selectedpackages" title="Select Package"><a data-businessid="'+data.id+'" data-businessname="' +data.company_name+ '"style="color:#ffffff" data-businessstate_id="'+data.state_id+'" > <i class="mdi mdi-package-variant" data-name="mdi-package-variant"></i> </a></button>&nbsp;                                                                                       <button class="btn btn-primary btn-sm mt-2 listofbusiness" title="Payment History"><a data-businessid="'+data.id+'" data-businessname="' +data.company_name+ '" style="color:#ffffff" > <i class="mdi mdi-wallet" data-name="mdi-package-variant"></i> </a></button>'

    //       }else if(role=="Tele-Marketing"){
    //           return '<button class="btn btn-info btn-sm mt-2 status_edit" data-toggle="modal" id="status_edit" data-target="#EditstatusModal" title="Status Edit"><a data-businessid="'+data.id+'" data-businessname="' +data.company_name+ '" style="color:#ffffff"> <i class="mdi mdi-pencil-box"></i> </a></button> &nbsp;                                                                                                                       <button class="btn btn-info btn-sm mt-2 selectedpackages" title="Select Package"><a data-businessid="'+data.id+'" data-businessname="' +data.company_name+ '"style="color:#ffffff" data-businessstate_id="'+data.state_id+'" > <i class="mdi mdi-package-variant" data-name="mdi-package-variant"></i> </a></button>&nbsp;                                                                                        <button class="btn btn-primary btn-sm mt-2 listofbusiness" title="Payment History"><a data-businessid="'+data.id+'" data-businessname="' +data.company_name+ '" style="color:#ffffff" > <i class="mdi mdi-wallet" data-name="mdi-package-variant"></i> </a></button>'
    //       } else{
   
    // return '<button class="btn btn-info btn-sm mt-2 status_edit" data-toggle="modal" id="status_edit" data-target="#EditstatusModal" title="Status Edit"><a data-businessid="'+data.id+'" data-businessname="' +data.company_name+ '" style="color:#ffffff"> <i class="mdi mdi-pencil-box"></i> </a></button> &nbsp;<button class="btn btn-info btn-sm mt-2  editbusiness" id="businessdata_edit" title="Business Edit" style="color:#0066ff"><a data-businessid="'+data.id+'" data-businessname="' +data.company_name+ '"  style="color:#ffffff"> <i class="mdi mdi-grease-pencil"></i> </a></button>&nbsp;        <button class="btn btn-danger btn-sm mt-2 business_delete" title="Business Delete" ><a data-businessid="'+data.id+'" data-businessname="' +data.company_name+ '" style="color:#ffffff" > <i class="mdi mdi-delete"></i> </a></button>&nbsp;                                                                      <button class="btn btn-info btn-sm mt-2 selectedpackages" title="Select Package"><a data-businessid="'+data.id+'" data-businessname="' +data.company_name+ '"style="color:#ffffff" data-businessstate_id="'+data.state_id+'" > <i class="mdi mdi-package-variant" data-name="mdi-package-variant"></i> </a></button>&nbsp;                             <button class="btn btn-primary btn-sm mt-2 listofbusiness" title="Payment History"><a data-businessid="'+data.id+'" data-businessname="' +data.company_name+ '" style="color:#ffffff" > <i class="mdi mdi-wallet" data-name="mdi-package-variant"></i> </a></button>'  }
    //        } }

   ]
       });

 
table.rows.add(data).draw();
 
 }

$('[data-toggle="modal"]').tooltip();


